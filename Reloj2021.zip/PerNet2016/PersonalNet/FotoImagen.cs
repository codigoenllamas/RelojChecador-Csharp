﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 01/09/2013
 * Time: 11:08 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace PersonalNet
{
	/// <summary>
	/// Description of FotoImagen.
	/// </summary>
	public partial class FotoImagen : Form
	{
		public FotoImagen()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void FotoImagenLoad(object sender, EventArgs e)
		{
	
		}
	}
}
