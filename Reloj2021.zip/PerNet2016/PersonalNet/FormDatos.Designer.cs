﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 28/06/2013
 * Time: 11:17 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class FormDatos
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDatos));
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.cmbStatus = new System.Windows.Forms.ComboBox();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.cmbRol = new System.Windows.Forms.ComboBox();
			this.label38 = new System.Windows.Forms.Label();
			this.label37 = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.Txt_curp = new System.Windows.Forms.TextBox();
			this.lbl_claveid = new System.Windows.Forms.Label();
			this.Txt_Nombre = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.rb_Mujer = new System.Windows.Forms.RadioButton();
			this.rb_Hombre = new System.Windows.Forms.RadioButton();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.Cbx_Txt_Depto = new System.Windows.Forms.ComboBox();
			this.Rch_Direccion = new System.Windows.Forms.RichTextBox();
			this.Txt_Depto = new System.Windows.Forms.TextBox();
			this.Rch_Comentario = new System.Windows.Forms.RichTextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.Txt_Puesto = new System.Windows.Forms.TextBox();
			this.Txt_Mail = new System.Windows.Forms.TextBox();
			this.Txt_celular = new System.Windows.Forms.TextBox();
			this.Txt_telCasa = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.Btn_cancelar = new System.Windows.Forms.Button();
			this.Btn_guardar = new System.Windows.Forms.Button();
			this.Btn_Nuevo = new System.Windows.Forms.Button();
			this.label20 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.label34 = new System.Windows.Forms.Label();
			this.Btn_ruta = new System.Windows.Forms.Button();
			this.Pic_Foto = new System.Windows.Forms.PictureBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.CmbActivo = new System.Windows.Forms.ComboBox();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.cmbRol2 = new System.Windows.Forms.ComboBox();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.Btn_ruta2 = new System.Windows.Forms.Button();
			this.Pic_Foto2 = new System.Windows.Forms.PictureBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.Txt_curp2 = new System.Windows.Forms.TextBox();
			this.lbl_claveid2 = new System.Windows.Forms.Label();
			this.Txt_Nombre2 = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.rb_Mujer2 = new System.Windows.Forms.RadioButton();
			this.rb_Hombre2 = new System.Windows.Forms.RadioButton();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.Rch_Direccion2 = new System.Windows.Forms.RichTextBox();
			this.Rch_Comentario2 = new System.Windows.Forms.RichTextBox();
			this.label24 = new System.Windows.Forms.Label();
			this.Txt_Puesto2 = new System.Windows.Forms.TextBox();
			this.Txt_Depto2 = new System.Windows.Forms.TextBox();
			this.Txt_Mail2 = new System.Windows.Forms.TextBox();
			this.Txt_celular2 = new System.Windows.Forms.TextBox();
			this.Txt_telCasa2 = new System.Windows.Forms.TextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.btnActual = new System.Windows.Forms.Button();
			this.cbx_lista = new System.Windows.Forms.ComboBox();
			this.lblSeleccionar = new System.Windows.Forms.Label();
			this.btnSelector = new System.Windows.Forms.Button();
			this.Btn_Ficha = new System.Windows.Forms.Button();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabPage4 = new System.Windows.Forms.TabPage();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.label45 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.lbl_TipoRol = new System.Windows.Forms.Label();
			this.label43 = new System.Windows.Forms.Label();
			this.label42 = new System.Windows.Forms.Label();
			this.lbl_RolNombre = new System.Windows.Forms.Label();
			this.label40 = new System.Windows.Forms.Label();
			this.label36 = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.label10 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.Btn_cerrar = new System.Windows.Forms.Button();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.groupBox10.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.Pic_Foto)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.groupBox11.SuspendLayout();
			this.groupBox12.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.Pic_Foto2)).BeginInit();
			this.groupBox5.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.tabPage4.SuspendLayout();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Location = new System.Drawing.Point(12, 23);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1026, 523);
			this.tabControl1.TabIndex = 1;
			// 
			// tabPage1
			// 
			this.tabPage1.BackColor = System.Drawing.Color.Pink;
			this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.tabPage1.Controls.Add(this.groupBox10);
			this.tabPage1.Controls.Add(this.groupBox9);
			this.tabPage1.Controls.Add(this.label38);
			this.tabPage1.Controls.Add(this.label37);
			this.tabPage1.Controls.Add(this.groupBox3);
			this.tabPage1.Controls.Add(this.groupBox1);
			this.tabPage1.Controls.Add(this.label19);
			this.tabPage1.Controls.Add(this.Btn_cancelar);
			this.tabPage1.Controls.Add(this.Btn_guardar);
			this.tabPage1.Controls.Add(this.Btn_Nuevo);
			this.tabPage1.Controls.Add(this.label20);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Controls.Add(this.groupBox4);
			this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(1018, 497);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "R.e.g.i.s.t.r.o";
			// 
			// groupBox10
			// 
			this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.groupBox10.Controls.Add(this.cmbStatus);
			this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox10.Location = new System.Drawing.Point(768, 315);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(186, 61);
			this.groupBox10.TabIndex = 105;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "Empleado Activo";
			this.groupBox10.Visible = false;
			// 
			// cmbStatus
			// 
			this.cmbStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.cmbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmbStatus.FormattingEnabled = true;
			this.cmbStatus.Items.AddRange(new object[] {
									"ACTIVO",
									"SUSPENDIDO"});
			this.cmbStatus.Location = new System.Drawing.Point(15, 25);
			this.cmbStatus.Name = "cmbStatus";
			this.cmbStatus.Size = new System.Drawing.Size(155, 21);
			this.cmbStatus.TabIndex = 96;
			// 
			// groupBox9
			// 
			this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.groupBox9.Controls.Add(this.cmbRol);
			this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox9.Location = new System.Drawing.Point(767, 395);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(186, 57);
			this.groupBox9.TabIndex = 104;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Tipo de Rol:";
			this.groupBox9.Visible = false;
			// 
			// cmbRol
			// 
			this.cmbRol.FormattingEnabled = true;
			this.cmbRol.Items.AddRange(new object[] {
									"EMPLEADO",
									"SYSADMIN"});
			this.cmbRol.Location = new System.Drawing.Point(15, 20);
			this.cmbRol.Name = "cmbRol";
			this.cmbRol.Size = new System.Drawing.Size(156, 23);
			this.cmbRol.TabIndex = 98;
			this.cmbRol.SelectedIndexChanged += new System.EventHandler(this.CmbRolSelectedIndexChanged);
			// 
			// label38
			// 
			this.label38.BackColor = System.Drawing.Color.DarkRed;
			this.label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label38.Location = new System.Drawing.Point(13, 451);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(690, 4);
			this.label38.TabIndex = 103;
			// 
			// label37
			// 
			this.label37.BackColor = System.Drawing.Color.DarkRed;
			this.label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label37.Location = new System.Drawing.Point(11, 25);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(4, 430);
			this.label37.TabIndex = 102;
			// 
			// groupBox3
			// 
			this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.groupBox3.Controls.Add(this.dateTimePicker1);
			this.groupBox3.Controls.Add(this.Txt_curp);
			this.groupBox3.Controls.Add(this.lbl_claveid);
			this.groupBox3.Controls.Add(this.Txt_Nombre);
			this.groupBox3.Controls.Add(this.label16);
			this.groupBox3.Controls.Add(this.label15);
			this.groupBox3.Controls.Add(this.label14);
			this.groupBox3.Controls.Add(this.label13);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.groupBox2);
			this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox3.Location = new System.Drawing.Point(21, 35);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(675, 132);
			this.groupBox3.TabIndex = 100;
			this.groupBox3.TabStop = false;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.dateTimePicker1.Location = new System.Drawing.Point(440, 70);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(198, 20);
			this.dateTimePicker1.TabIndex = 49;
			// 
			// Txt_curp
			// 
			this.Txt_curp.BackColor = System.Drawing.Color.Thistle;
			this.Txt_curp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_curp.Location = new System.Drawing.Point(163, 99);
			this.Txt_curp.Name = "Txt_curp";
			this.Txt_curp.Size = new System.Drawing.Size(445, 24);
			this.Txt_curp.TabIndex = 50;
			// 
			// lbl_claveid
			// 
			this.lbl_claveid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.lbl_claveid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_claveid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_claveid.Location = new System.Drawing.Point(163, 7);
			this.lbl_claveid.Name = "lbl_claveid";
			this.lbl_claveid.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_claveid.Size = new System.Drawing.Size(445, 23);
			this.lbl_claveid.TabIndex = 45;
			this.lbl_claveid.Text = "Pulse, NUEVO para Ingresar Datos";
			this.lbl_claveid.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Txt_Nombre
			// 
			this.Txt_Nombre.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Nombre.Location = new System.Drawing.Point(163, 31);
			this.Txt_Nombre.Name = "Txt_Nombre";
			this.Txt_Nombre.Size = new System.Drawing.Size(445, 24);
			this.Txt_Nombre.TabIndex = 46;
			// 
			// label16
			// 
			this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.Location = new System.Drawing.Point(10, 32);
			this.label16.Name = "label16";
			this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label16.Size = new System.Drawing.Size(148, 23);
			this.label16.TabIndex = 44;
			this.label16.Text = "NOMBRE COMPLETO:";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label15
			// 
			this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.Location = new System.Drawing.Point(10, 65);
			this.label15.Name = "label15";
			this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label15.Size = new System.Drawing.Size(148, 23);
			this.label15.TabIndex = 43;
			this.label15.Text = "SEXO:";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(340, 70);
			this.label14.Name = "label14";
			this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label14.Size = new System.Drawing.Size(94, 19);
			this.label14.TabIndex = 42;
			this.label14.Text = "FEC. DE NAC. :";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.Location = new System.Drawing.Point(9, 99);
			this.label13.Name = "label13";
			this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label13.Size = new System.Drawing.Size(148, 23);
			this.label13.TabIndex = 41;
			this.label13.Text = "CURP:";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(10, 6);
			this.label4.Name = "label4";
			this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label4.Size = new System.Drawing.Size(148, 23);
			this.label4.TabIndex = 33;
			this.label4.Text = "NUM. EMPLEADO:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.rb_Mujer);
			this.groupBox2.Controls.Add(this.rb_Hombre);
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox2.ForeColor = System.Drawing.Color.Red;
			this.groupBox2.Location = new System.Drawing.Point(163, 60);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
			this.groupBox2.Size = new System.Drawing.Size(172, 34);
			this.groupBox2.TabIndex = 47;
			this.groupBox2.TabStop = false;
			// 
			// rb_Mujer
			// 
			this.rb_Mujer.Location = new System.Drawing.Point(91, 8);
			this.rb_Mujer.Margin = new System.Windows.Forms.Padding(2);
			this.rb_Mujer.Name = "rb_Mujer";
			this.rb_Mujer.Size = new System.Drawing.Size(72, 20);
			this.rb_Mujer.TabIndex = 1;
			this.rb_Mujer.TabStop = true;
			this.rb_Mujer.Text = "&Mujer";
			this.rb_Mujer.UseVisualStyleBackColor = true;
			// 
			// rb_Hombre
			// 
			this.rb_Hombre.Location = new System.Drawing.Point(4, 8);
			this.rb_Hombre.Margin = new System.Windows.Forms.Padding(2);
			this.rb_Hombre.Name = "rb_Hombre";
			this.rb_Hombre.Size = new System.Drawing.Size(83, 20);
			this.rb_Hombre.TabIndex = 0;
			this.rb_Hombre.TabStop = true;
			this.rb_Hombre.Text = "&Hombre";
			this.rb_Hombre.UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.groupBox1.Controls.Add(this.Cbx_Txt_Depto);
			this.groupBox1.Controls.Add(this.Rch_Direccion);
			this.groupBox1.Controls.Add(this.Txt_Depto);
			this.groupBox1.Controls.Add(this.Rch_Comentario);
			this.groupBox1.Controls.Add(this.label18);
			this.groupBox1.Controls.Add(this.Txt_Puesto);
			this.groupBox1.Controls.Add(this.Txt_Mail);
			this.groupBox1.Controls.Add(this.Txt_celular);
			this.groupBox1.Controls.Add(this.Txt_telCasa);
			this.groupBox1.Controls.Add(this.label12);
			this.groupBox1.Controls.Add(this.label9);
			this.groupBox1.Controls.Add(this.label8);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Location = new System.Drawing.Point(21, 175);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(675, 264);
			this.groupBox1.TabIndex = 99;
			this.groupBox1.TabStop = false;
			// 
			// Cbx_Txt_Depto
			// 
			this.Cbx_Txt_Depto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.Cbx_Txt_Depto.FormattingEnabled = true;
			this.Cbx_Txt_Depto.Items.AddRange(new object[] {
									"GERENTE",
									"SISTEMAS",
									"STAFF",
									"EMPLEADO"});
			this.Cbx_Txt_Depto.Location = new System.Drawing.Point(171, 147);
			this.Cbx_Txt_Depto.Name = "Cbx_Txt_Depto";
			this.Cbx_Txt_Depto.Size = new System.Drawing.Size(185, 24);
			this.Cbx_Txt_Depto.TabIndex = 67;
			this.Cbx_Txt_Depto.SelectedIndexChanged += new System.EventHandler(this.Cbx_Txt_DeptoSelectedIndexChanged);
			// 
			// Rch_Direccion
			// 
			this.Rch_Direccion.BackColor = System.Drawing.Color.Thistle;
			this.Rch_Direccion.Location = new System.Drawing.Point(171, 14);
			this.Rch_Direccion.Name = "Rch_Direccion";
			this.Rch_Direccion.Size = new System.Drawing.Size(445, 49);
			this.Rch_Direccion.TabIndex = 66;
			this.Rch_Direccion.Text = "";
			// 
			// Txt_Depto
			// 
			this.Txt_Depto.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Depto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Depto.Location = new System.Drawing.Point(506, 147);
			this.Txt_Depto.Name = "Txt_Depto";
			this.Txt_Depto.Size = new System.Drawing.Size(110, 24);
			this.Txt_Depto.TabIndex = 55;
			this.Txt_Depto.Visible = false;
			// 
			// Rch_Comentario
			// 
			this.Rch_Comentario.BackColor = System.Drawing.Color.Thistle;
			this.Rch_Comentario.Location = new System.Drawing.Point(171, 200);
			this.Rch_Comentario.Name = "Rch_Comentario";
			this.Rch_Comentario.Size = new System.Drawing.Size(445, 52);
			this.Rch_Comentario.TabIndex = 57;
			this.Rch_Comentario.Text = "";
			// 
			// label18
			// 
			this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.Location = new System.Drawing.Point(13, 201);
			this.label18.Name = "label18";
			this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label18.Size = new System.Drawing.Size(148, 51);
			this.label18.TabIndex = 36;
			this.label18.Text = "DESCRIPCION DEL PUESTO";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// Txt_Puesto
			// 
			this.Txt_Puesto.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Puesto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Puesto.Location = new System.Drawing.Point(171, 172);
			this.Txt_Puesto.Name = "Txt_Puesto";
			this.Txt_Puesto.Size = new System.Drawing.Size(445, 24);
			this.Txt_Puesto.TabIndex = 56;
			// 
			// Txt_Mail
			// 
			this.Txt_Mail.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Mail.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Mail.Location = new System.Drawing.Point(171, 121);
			this.Txt_Mail.Name = "Txt_Mail";
			this.Txt_Mail.Size = new System.Drawing.Size(445, 24);
			this.Txt_Mail.TabIndex = 54;
			// 
			// Txt_celular
			// 
			this.Txt_celular.BackColor = System.Drawing.Color.Thistle;
			this.Txt_celular.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_celular.Location = new System.Drawing.Point(171, 95);
			this.Txt_celular.Name = "Txt_celular";
			this.Txt_celular.Size = new System.Drawing.Size(445, 24);
			this.Txt_celular.TabIndex = 53;
			// 
			// Txt_telCasa
			// 
			this.Txt_telCasa.BackColor = System.Drawing.Color.Thistle;
			this.Txt_telCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_telCasa.Location = new System.Drawing.Point(171, 68);
			this.Txt_telCasa.Name = "Txt_telCasa";
			this.Txt_telCasa.Size = new System.Drawing.Size(445, 24);
			this.Txt_telCasa.TabIndex = 52;
			// 
			// label12
			// 
			this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(13, 13);
			this.label12.Name = "label12";
			this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label12.Size = new System.Drawing.Size(148, 46);
			this.label12.TabIndex = 40;
			this.label12.Text = "DIRECCION COMPLETO:";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label9
			// 
			this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(13, 70);
			this.label9.Name = "label9";
			this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label9.Size = new System.Drawing.Size(148, 23);
			this.label9.TabIndex = 39;
			this.label9.Text = "TELEFONO FIJO:";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(13, 96);
			this.label8.Name = "label8";
			this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label8.Size = new System.Drawing.Size(148, 23);
			this.label8.TabIndex = 38;
			this.label8.Text = "CELULAR:";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(13, 121);
			this.label7.Name = "label7";
			this.label7.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label7.Size = new System.Drawing.Size(148, 23);
			this.label7.TabIndex = 37;
			this.label7.Text = "CORREO ELECTRONICO:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(13, 147);
			this.label6.Name = "label6";
			this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label6.Size = new System.Drawing.Size(148, 23);
			this.label6.TabIndex = 35;
			this.label6.Text = "AREA:";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(13, 173);
			this.label5.Name = "label5";
			this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label5.Size = new System.Drawing.Size(148, 23);
			this.label5.TabIndex = 34;
			this.label5.Text = "PUESTO:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label19
			// 
			this.label19.BackColor = System.Drawing.Color.DarkRed;
			this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label19.Location = new System.Drawing.Point(702, 25);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(4, 430);
			this.label19.TabIndex = 90;
			// 
			// Btn_cancelar
			// 
			this.Btn_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_cancelar.Location = new System.Drawing.Point(586, 458);
			this.Btn_cancelar.Name = "Btn_cancelar";
			this.Btn_cancelar.Size = new System.Drawing.Size(120, 34);
			this.Btn_cancelar.TabIndex = 87;
			this.Btn_cancelar.Text = "&Cancelar";
			this.Btn_cancelar.UseVisualStyleBackColor = true;
			this.Btn_cancelar.Click += new System.EventHandler(this.Btn_cancelarClick);
			// 
			// Btn_guardar
			// 
			this.Btn_guardar.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.Btn_guardar.FlatAppearance.BorderSize = 3;
			this.Btn_guardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Purple;
			this.Btn_guardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
			this.Btn_guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_guardar.ForeColor = System.Drawing.Color.Black;
			this.Btn_guardar.Location = new System.Drawing.Point(300, 458);
			this.Btn_guardar.Name = "Btn_guardar";
			this.Btn_guardar.Size = new System.Drawing.Size(120, 34);
			this.Btn_guardar.TabIndex = 86;
			this.Btn_guardar.Text = "&Guardar";
			this.Btn_guardar.UseVisualStyleBackColor = true;
			this.Btn_guardar.Click += new System.EventHandler(this.Btn_guardarClick);
			// 
			// Btn_Nuevo
			// 
			this.Btn_Nuevo.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.Btn_Nuevo.FlatAppearance.BorderSize = 3;
			this.Btn_Nuevo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Purple;
			this.Btn_Nuevo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
			this.Btn_Nuevo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_Nuevo.ForeColor = System.Drawing.Color.Black;
			this.Btn_Nuevo.Location = new System.Drawing.Point(11, 458);
			this.Btn_Nuevo.Name = "Btn_Nuevo";
			this.Btn_Nuevo.Size = new System.Drawing.Size(120, 34);
			this.Btn_Nuevo.TabIndex = 91;
			this.Btn_Nuevo.Text = "&Nuevo";
			this.Btn_Nuevo.UseVisualStyleBackColor = true;
			this.Btn_Nuevo.Click += new System.EventHandler(this.Btn_NuevoClick);
			// 
			// label20
			// 
			this.label20.BackColor = System.Drawing.Color.DarkRed;
			this.label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label20.Location = new System.Drawing.Point(14, 168);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(690, 4);
			this.label20.TabIndex = 84;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.DarkRed;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label1.Location = new System.Drawing.Point(13, 25);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(690, 4);
			this.label1.TabIndex = 85;
			// 
			// groupBox4
			// 
			this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.groupBox4.Controls.Add(this.label34);
			this.groupBox4.Controls.Add(this.Btn_ruta);
			this.groupBox4.Controls.Add(this.Pic_Foto);
			this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox4.Location = new System.Drawing.Point(767, 6);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(186, 284);
			this.groupBox4.TabIndex = 101;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Fotografia";
			// 
			// label34
			// 
			this.label34.BackColor = System.Drawing.Color.DarkRed;
			this.label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label34.Location = new System.Drawing.Point(0, 211);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(187, 4);
			this.label34.TabIndex = 106;
			// 
			// Btn_ruta
			// 
			this.Btn_ruta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.Btn_ruta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_ruta.BackgroundImage")));
			this.Btn_ruta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.Btn_ruta.Enabled = false;
			this.Btn_ruta.FlatAppearance.BorderSize = 5;
			this.Btn_ruta.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_ruta.Location = new System.Drawing.Point(6, 227);
			this.Btn_ruta.Name = "Btn_ruta";
			this.Btn_ruta.Size = new System.Drawing.Size(174, 45);
			this.Btn_ruta.TabIndex = 64;
			this.Btn_ruta.UseVisualStyleBackColor = false;
			this.Btn_ruta.Click += new System.EventHandler(this.Btn_rutaClick);
			// 
			// Pic_Foto
			// 
			this.Pic_Foto.BackColor = System.Drawing.SystemColors.Window;
			this.Pic_Foto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Pic_Foto.Location = new System.Drawing.Point(15, 22);
			this.Pic_Foto.Name = "Pic_Foto";
			this.Pic_Foto.Size = new System.Drawing.Size(155, 178);
			this.Pic_Foto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.Pic_Foto.TabIndex = 62;
			this.Pic_Foto.TabStop = false;
			// 
			// tabPage2
			// 
			this.tabPage2.BackColor = System.Drawing.Color.CornflowerBlue;
			this.tabPage2.Controls.Add(this.groupBox8);
			this.tabPage2.Controls.Add(this.groupBox11);
			this.tabPage2.Controls.Add(this.groupBox12);
			this.tabPage2.Controls.Add(this.label2);
			this.tabPage2.Controls.Add(this.label3);
			this.tabPage2.Controls.Add(this.groupBox5);
			this.tabPage2.Controls.Add(this.groupBox7);
			this.tabPage2.Controls.Add(this.label31);
			this.tabPage2.Controls.Add(this.label32);
			this.tabPage2.Controls.Add(this.label33);
			this.tabPage2.Controls.Add(this.button2);
			this.tabPage2.Controls.Add(this.btnActual);
			this.tabPage2.Controls.Add(this.cbx_lista);
			this.tabPage2.Controls.Add(this.lblSeleccionar);
			this.tabPage2.Controls.Add(this.btnSelector);
			this.tabPage2.Controls.Add(this.Btn_Ficha);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(1018, 497);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Actualizar / Impresion";
			// 
			// groupBox8
			// 
			this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.groupBox8.Controls.Add(this.CmbActivo);
			this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox8.Location = new System.Drawing.Point(773, 319);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(186, 61);
			this.groupBox8.TabIndex = 0;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Empleado Activo";
			// 
			// CmbActivo
			// 
			this.CmbActivo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.CmbActivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CmbActivo.FormattingEnabled = true;
			this.CmbActivo.Items.AddRange(new object[] {
									"SI",
									"NO"});
			this.CmbActivo.Location = new System.Drawing.Point(15, 25);
			this.CmbActivo.Name = "CmbActivo";
			this.CmbActivo.Size = new System.Drawing.Size(155, 21);
			this.CmbActivo.TabIndex = 96;
			this.CmbActivo.SelectedIndexChanged += new System.EventHandler(this.CmbActivoSelectedIndexChanged);
			// 
			// groupBox11
			// 
			this.groupBox11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.groupBox11.Controls.Add(this.cmbRol2);
			this.groupBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox11.Location = new System.Drawing.Point(773, 402);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(186, 57);
			this.groupBox11.TabIndex = 133;
			this.groupBox11.TabStop = false;
			this.groupBox11.Text = "Habilitar Rol ";
			// 
			// cmbRol2
			// 
			this.cmbRol2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.cmbRol2.FormattingEnabled = true;
			this.cmbRol2.Items.AddRange(new object[] {
									"EMPLEADO",
									"SYSADMIN"});
			this.cmbRol2.Location = new System.Drawing.Point(15, 20);
			this.cmbRol2.Name = "cmbRol2";
			this.cmbRol2.Size = new System.Drawing.Size(156, 23);
			this.cmbRol2.TabIndex = 98;
			this.cmbRol2.SelectedIndexChanged += new System.EventHandler(this.CmbRol2SelectedIndexChanged);
			// 
			// groupBox12
			// 
			this.groupBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.groupBox12.Controls.Add(this.Btn_ruta2);
			this.groupBox12.Controls.Add(this.Pic_Foto2);
			this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox12.Location = new System.Drawing.Point(773, 47);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(186, 253);
			this.groupBox12.TabIndex = 132;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "Fotografia";
			// 
			// Btn_ruta2
			// 
			this.Btn_ruta2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.Btn_ruta2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_ruta2.BackgroundImage")));
			this.Btn_ruta2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.Btn_ruta2.Enabled = false;
			this.Btn_ruta2.FlatAppearance.BorderSize = 5;
			this.Btn_ruta2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_ruta2.Location = new System.Drawing.Point(6, 196);
			this.Btn_ruta2.Name = "Btn_ruta2";
			this.Btn_ruta2.Size = new System.Drawing.Size(174, 45);
			this.Btn_ruta2.TabIndex = 135;
			this.Btn_ruta2.UseVisualStyleBackColor = false;
			this.Btn_ruta2.Click += new System.EventHandler(this.Button3Click);
			// 
			// Pic_Foto2
			// 
			this.Pic_Foto2.BackColor = System.Drawing.SystemColors.Window;
			this.Pic_Foto2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.Pic_Foto2.Location = new System.Drawing.Point(15, 22);
			this.Pic_Foto2.Name = "Pic_Foto2";
			this.Pic_Foto2.Size = new System.Drawing.Size(155, 158);
			this.Pic_Foto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.Pic_Foto2.TabIndex = 62;
			this.Pic_Foto2.TabStop = false;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.DarkRed;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label2.Location = new System.Drawing.Point(25, 453);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(690, 4);
			this.label2.TabIndex = 131;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.DarkRed;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label3.Location = new System.Drawing.Point(23, 43);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(4, 410);
			this.label3.TabIndex = 130;
			// 
			// groupBox5
			// 
			this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.groupBox5.Controls.Add(this.dateTimePicker2);
			this.groupBox5.Controls.Add(this.Txt_curp2);
			this.groupBox5.Controls.Add(this.lbl_claveid2);
			this.groupBox5.Controls.Add(this.Txt_Nombre2);
			this.groupBox5.Controls.Add(this.label11);
			this.groupBox5.Controls.Add(this.label17);
			this.groupBox5.Controls.Add(this.label21);
			this.groupBox5.Controls.Add(this.label22);
			this.groupBox5.Controls.Add(this.label23);
			this.groupBox5.Controls.Add(this.groupBox6);
			this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox5.Location = new System.Drawing.Point(33, 46);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(675, 132);
			this.groupBox5.TabIndex = 129;
			this.groupBox5.TabStop = false;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Location = new System.Drawing.Point(436, 70);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(211, 20);
			this.dateTimePicker2.TabIndex = 49;
			// 
			// Txt_curp2
			// 
			this.Txt_curp2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_curp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_curp2.Location = new System.Drawing.Point(163, 99);
			this.Txt_curp2.Name = "Txt_curp2";
			this.Txt_curp2.Size = new System.Drawing.Size(445, 24);
			this.Txt_curp2.TabIndex = 50;
			// 
			// lbl_claveid2
			// 
			this.lbl_claveid2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.lbl_claveid2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_claveid2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_claveid2.Location = new System.Drawing.Point(163, 7);
			this.lbl_claveid2.Name = "lbl_claveid2";
			this.lbl_claveid2.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_claveid2.Size = new System.Drawing.Size(445, 23);
			this.lbl_claveid2.TabIndex = 45;
			this.lbl_claveid2.Text = "Numero Empleado";
			this.lbl_claveid2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Txt_Nombre2
			// 
			this.Txt_Nombre2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Nombre2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Nombre2.Location = new System.Drawing.Point(163, 31);
			this.Txt_Nombre2.Name = "Txt_Nombre2";
			this.Txt_Nombre2.Size = new System.Drawing.Size(445, 24);
			this.Txt_Nombre2.TabIndex = 46;
			// 
			// label11
			// 
			this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(10, 32);
			this.label11.Name = "label11";
			this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label11.Size = new System.Drawing.Size(148, 23);
			this.label11.TabIndex = 44;
			this.label11.Text = "NOMBRE COMPLETO:";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label17
			// 
			this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(10, 65);
			this.label17.Name = "label17";
			this.label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label17.Size = new System.Drawing.Size(148, 23);
			this.label17.TabIndex = 43;
			this.label17.Text = "SEXO:";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label21
			// 
			this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.Location = new System.Drawing.Point(328, 70);
			this.label21.Name = "label21";
			this.label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label21.Size = new System.Drawing.Size(102, 19);
			this.label21.TabIndex = 42;
			this.label21.Text = "FEC. DE NAC. :";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label22
			// 
			this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.Location = new System.Drawing.Point(9, 99);
			this.label22.Name = "label22";
			this.label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label22.Size = new System.Drawing.Size(148, 23);
			this.label22.TabIndex = 41;
			this.label22.Text = "CURP:";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label23
			// 
			this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.Location = new System.Drawing.Point(10, 6);
			this.label23.Name = "label23";
			this.label23.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label23.Size = new System.Drawing.Size(148, 23);
			this.label23.TabIndex = 33;
			this.label23.Text = "NUM. EMPLEADO:";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.rb_Mujer2);
			this.groupBox6.Controls.Add(this.rb_Hombre2);
			this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox6.ForeColor = System.Drawing.Color.Red;
			this.groupBox6.Location = new System.Drawing.Point(163, 60);
			this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
			this.groupBox6.Size = new System.Drawing.Size(160, 34);
			this.groupBox6.TabIndex = 47;
			this.groupBox6.TabStop = false;
			// 
			// rb_Mujer2
			// 
			this.rb_Mujer2.Location = new System.Drawing.Point(91, 8);
			this.rb_Mujer2.Margin = new System.Windows.Forms.Padding(2);
			this.rb_Mujer2.Name = "rb_Mujer2";
			this.rb_Mujer2.Size = new System.Drawing.Size(65, 20);
			this.rb_Mujer2.TabIndex = 1;
			this.rb_Mujer2.TabStop = true;
			this.rb_Mujer2.Text = "&Mujer";
			this.rb_Mujer2.UseVisualStyleBackColor = true;
			// 
			// rb_Hombre2
			// 
			this.rb_Hombre2.Location = new System.Drawing.Point(4, 8);
			this.rb_Hombre2.Margin = new System.Windows.Forms.Padding(2);
			this.rb_Hombre2.Name = "rb_Hombre2";
			this.rb_Hombre2.Size = new System.Drawing.Size(83, 20);
			this.rb_Hombre2.TabIndex = 0;
			this.rb_Hombre2.TabStop = true;
			this.rb_Hombre2.Text = "&Hombre";
			this.rb_Hombre2.UseVisualStyleBackColor = true;
			// 
			// groupBox7
			// 
			this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.groupBox7.Controls.Add(this.Rch_Direccion2);
			this.groupBox7.Controls.Add(this.Rch_Comentario2);
			this.groupBox7.Controls.Add(this.label24);
			this.groupBox7.Controls.Add(this.Txt_Puesto2);
			this.groupBox7.Controls.Add(this.Txt_Depto2);
			this.groupBox7.Controls.Add(this.Txt_Mail2);
			this.groupBox7.Controls.Add(this.Txt_celular2);
			this.groupBox7.Controls.Add(this.Txt_telCasa2);
			this.groupBox7.Controls.Add(this.label25);
			this.groupBox7.Controls.Add(this.label26);
			this.groupBox7.Controls.Add(this.label27);
			this.groupBox7.Controls.Add(this.label28);
			this.groupBox7.Controls.Add(this.label29);
			this.groupBox7.Controls.Add(this.label30);
			this.groupBox7.Location = new System.Drawing.Point(33, 187);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(675, 264);
			this.groupBox7.TabIndex = 128;
			this.groupBox7.TabStop = false;
			// 
			// Rch_Direccion2
			// 
			this.Rch_Direccion2.BackColor = System.Drawing.Color.Thistle;
			this.Rch_Direccion2.Location = new System.Drawing.Point(171, 14);
			this.Rch_Direccion2.Name = "Rch_Direccion2";
			this.Rch_Direccion2.Size = new System.Drawing.Size(445, 49);
			this.Rch_Direccion2.TabIndex = 66;
			this.Rch_Direccion2.Text = "";
			// 
			// Rch_Comentario2
			// 
			this.Rch_Comentario2.BackColor = System.Drawing.Color.Thistle;
			this.Rch_Comentario2.Location = new System.Drawing.Point(171, 200);
			this.Rch_Comentario2.Name = "Rch_Comentario2";
			this.Rch_Comentario2.Size = new System.Drawing.Size(445, 52);
			this.Rch_Comentario2.TabIndex = 57;
			this.Rch_Comentario2.Text = "";
			// 
			// label24
			// 
			this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.Location = new System.Drawing.Point(13, 201);
			this.label24.Name = "label24";
			this.label24.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label24.Size = new System.Drawing.Size(148, 23);
			this.label24.TabIndex = 36;
			this.label24.Text = "COMENTARIO:";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// Txt_Puesto2
			// 
			this.Txt_Puesto2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Puesto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Puesto2.Location = new System.Drawing.Point(171, 172);
			this.Txt_Puesto2.Name = "Txt_Puesto2";
			this.Txt_Puesto2.Size = new System.Drawing.Size(445, 24);
			this.Txt_Puesto2.TabIndex = 56;
			// 
			// Txt_Depto2
			// 
			this.Txt_Depto2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Depto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Depto2.Location = new System.Drawing.Point(171, 145);
			this.Txt_Depto2.Name = "Txt_Depto2";
			this.Txt_Depto2.Size = new System.Drawing.Size(445, 24);
			this.Txt_Depto2.TabIndex = 55;
			// 
			// Txt_Mail2
			// 
			this.Txt_Mail2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_Mail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_Mail2.Location = new System.Drawing.Point(171, 121);
			this.Txt_Mail2.Name = "Txt_Mail2";
			this.Txt_Mail2.Size = new System.Drawing.Size(445, 24);
			this.Txt_Mail2.TabIndex = 54;
			// 
			// Txt_celular2
			// 
			this.Txt_celular2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_celular2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_celular2.Location = new System.Drawing.Point(171, 95);
			this.Txt_celular2.Name = "Txt_celular2";
			this.Txt_celular2.Size = new System.Drawing.Size(445, 24);
			this.Txt_celular2.TabIndex = 53;
			// 
			// Txt_telCasa2
			// 
			this.Txt_telCasa2.BackColor = System.Drawing.Color.Thistle;
			this.Txt_telCasa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Txt_telCasa2.Location = new System.Drawing.Point(171, 68);
			this.Txt_telCasa2.Name = "Txt_telCasa2";
			this.Txt_telCasa2.Size = new System.Drawing.Size(445, 24);
			this.Txt_telCasa2.TabIndex = 52;
			// 
			// label25
			// 
			this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.Location = new System.Drawing.Point(13, 13);
			this.label25.Name = "label25";
			this.label25.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label25.Size = new System.Drawing.Size(148, 46);
			this.label25.TabIndex = 40;
			this.label25.Text = "DIRECCION COMPLETO:";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label26
			// 
			this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.Location = new System.Drawing.Point(13, 70);
			this.label26.Name = "label26";
			this.label26.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label26.Size = new System.Drawing.Size(148, 23);
			this.label26.TabIndex = 39;
			this.label26.Text = "TELEFONO FIJO:";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label27
			// 
			this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label27.Location = new System.Drawing.Point(13, 96);
			this.label27.Name = "label27";
			this.label27.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label27.Size = new System.Drawing.Size(148, 23);
			this.label27.TabIndex = 38;
			this.label27.Text = "CELULAR:";
			this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label28
			// 
			this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label28.Location = new System.Drawing.Point(13, 121);
			this.label28.Name = "label28";
			this.label28.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label28.Size = new System.Drawing.Size(148, 23);
			this.label28.TabIndex = 37;
			this.label28.Text = "CORREO ELECTRONICO:";
			this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label29
			// 
			this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label29.Location = new System.Drawing.Point(13, 147);
			this.label29.Name = "label29";
			this.label29.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label29.Size = new System.Drawing.Size(148, 23);
			this.label29.TabIndex = 35;
			this.label29.Text = "DEPARTAMENTO:";
			this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label30
			// 
			this.label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label30.Location = new System.Drawing.Point(13, 173);
			this.label30.Name = "label30";
			this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label30.Size = new System.Drawing.Size(148, 23);
			this.label30.TabIndex = 34;
			this.label30.Text = "PUESTO:";
			this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label31
			// 
			this.label31.BackColor = System.Drawing.Color.DarkRed;
			this.label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label31.Location = new System.Drawing.Point(714, 42);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(4, 410);
			this.label31.TabIndex = 126;
			// 
			// label32
			// 
			this.label32.BackColor = System.Drawing.Color.DarkRed;
			this.label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label32.Location = new System.Drawing.Point(26, 180);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(690, 4);
			this.label32.TabIndex = 122;
			// 
			// label33
			// 
			this.label33.BackColor = System.Drawing.Color.DarkRed;
			this.label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label33.Location = new System.Drawing.Point(25, 39);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(690, 4);
			this.label33.TabIndex = 123;
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.Location = new System.Drawing.Point(598, 459);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(120, 34);
			this.button2.TabIndex = 107;
			this.button2.Text = "&Cancelar";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// btnActual
			// 
			this.btnActual.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.btnActual.FlatAppearance.BorderSize = 3;
			this.btnActual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Purple;
			this.btnActual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
			this.btnActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnActual.ForeColor = System.Drawing.Color.Black;
			this.btnActual.Location = new System.Drawing.Point(25, 459);
			this.btnActual.Name = "btnActual";
			this.btnActual.Size = new System.Drawing.Size(165, 34);
			this.btnActual.TabIndex = 114;
			this.btnActual.Text = "&Actualizar";
			this.btnActual.UseVisualStyleBackColor = true;
			this.btnActual.Click += new System.EventHandler(this.BtnActualClick);
			// 
			// cbx_lista
			// 
			this.cbx_lista.BackColor = System.Drawing.SystemColors.Window;
			this.cbx_lista.Enabled = false;
			this.cbx_lista.FormattingEnabled = true;
			this.cbx_lista.Location = new System.Drawing.Point(264, 10);
			this.cbx_lista.Name = "cbx_lista";
			this.cbx_lista.Size = new System.Drawing.Size(396, 21);
			this.cbx_lista.TabIndex = 108;
			this.cbx_lista.SelectedIndexChanged += new System.EventHandler(this.Cbx_listaSelectedIndexChanged);
			// 
			// lblSeleccionar
			// 
			this.lblSeleccionar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.lblSeleccionar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSeleccionar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSeleccionar.Location = new System.Drawing.Point(666, 10);
			this.lblSeleccionar.Name = "lblSeleccionar";
			this.lblSeleccionar.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lblSeleccionar.Size = new System.Drawing.Size(177, 23);
			this.lblSeleccionar.TabIndex = 113;
			this.lblSeleccionar.Text = "<-- Seleccionar";
			this.lblSeleccionar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.lblSeleccionar.Visible = false;
			// 
			// btnSelector
			// 
			this.btnSelector.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.btnSelector.FlatAppearance.BorderSize = 3;
			this.btnSelector.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Purple;
			this.btnSelector.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
			this.btnSelector.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSelector.ForeColor = System.Drawing.Color.Black;
			this.btnSelector.Location = new System.Drawing.Point(25, 5);
			this.btnSelector.Name = "btnSelector";
			this.btnSelector.Size = new System.Drawing.Size(233, 32);
			this.btnSelector.TabIndex = 112;
			this.btnSelector.Text = "&Ver Empleados";
			this.btnSelector.UseVisualStyleBackColor = true;
			this.btnSelector.Click += new System.EventHandler(this.BtnSelectorClick);
			// 
			// Btn_Ficha
			// 
			this.Btn_Ficha.Enabled = false;
			this.Btn_Ficha.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_Ficha.Location = new System.Drawing.Point(302, 459);
			this.Btn_Ficha.Name = "Btn_Ficha";
			this.Btn_Ficha.Size = new System.Drawing.Size(120, 34);
			this.Btn_Ficha.TabIndex = 103;
			this.Btn_Ficha.Text = "&Imprimir";
			this.Btn_Ficha.UseVisualStyleBackColor = true;
			this.Btn_Ficha.Click += new System.EventHandler(this.Btn_FichaClick);
			// 
			// tabPage3
			// 
			this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.tabPage3.Controls.Add(this.dataGridView1);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(1018, 497);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Depurar Lista";
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
									this.Column3,
									this.Column1});
			this.dataGridView1.Location = new System.Drawing.Point(116, 52);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(626, 427);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView1CellClick);
			this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.DataGridView1CellFormatting);
			this.dataGridView1.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DataGridView1RowPostPaint);
			// 
			// Column3
			// 
			this.Column3.HeaderText = "Num. Emp.";
			this.Column3.Name = "Column3";
			// 
			// Column1
			// 
			this.Column1.HeaderText = "NOMBRE DEL EMPLEADO";
			this.Column1.Name = "Column1";
			this.Column1.Width = 300;
			// 
			// tabPage4
			// 
			this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.tabPage4.Controls.Add(this.button6);
			this.tabPage4.Controls.Add(this.button5);
			this.tabPage4.Controls.Add(this.label45);
			this.tabPage4.Controls.Add(this.button1);
			this.tabPage4.Controls.Add(this.lbl_TipoRol);
			this.tabPage4.Controls.Add(this.label43);
			this.tabPage4.Controls.Add(this.label42);
			this.tabPage4.Controls.Add(this.lbl_RolNombre);
			this.tabPage4.Controls.Add(this.label40);
			this.tabPage4.Controls.Add(this.label36);
			this.tabPage4.Controls.Add(this.label35);
			this.tabPage4.Controls.Add(this.comboBox2);
			this.tabPage4.Controls.Add(this.label10);
			this.tabPage4.Controls.Add(this.comboBox1);
			this.tabPage4.Location = new System.Drawing.Point(4, 22);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new System.Drawing.Size(1018, 497);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "Asignar Permiso Grupal";
			// 
			// button6
			// 
			this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button6.ForeColor = System.Drawing.Color.Blue;
			this.button6.Location = new System.Drawing.Point(58, 346);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(118, 34);
			this.button6.TabIndex = 130;
			this.button6.Text = "Aceptar";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.Button6Click);
			// 
			// button5
			// 
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.Blue;
			this.button5.Location = new System.Drawing.Point(15, 20);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(180, 31);
			this.button5.TabIndex = 128;
			this.button5.Text = "Visualizar";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.Button5Click);
			// 
			// label45
			// 
			this.label45.BackColor = System.Drawing.Color.DarkRed;
			this.label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label45.Location = new System.Drawing.Point(58, 198);
			this.label45.Name = "label45";
			this.label45.Size = new System.Drawing.Size(560, 4);
			this.label45.TabIndex = 126;
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(474, 346);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(120, 34);
			this.button1.TabIndex = 125;
			this.button1.Text = "&Cancelar";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// lbl_TipoRol
			// 
			this.lbl_TipoRol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.lbl_TipoRol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_TipoRol.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_TipoRol.Location = new System.Drawing.Point(58, 297);
			this.lbl_TipoRol.Name = "lbl_TipoRol";
			this.lbl_TipoRol.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_TipoRol.Size = new System.Drawing.Size(239, 23);
			this.lbl_TipoRol.TabIndex = 123;
			this.lbl_TipoRol.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label43
			// 
			this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label43.Location = new System.Drawing.Point(58, 265);
			this.label43.Name = "label43";
			this.label43.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label43.Size = new System.Drawing.Size(183, 23);
			this.label43.TabIndex = 122;
			this.label43.Text = "ADMINISTRA AL GRUPO";
			this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label42
			// 
			this.label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label42.Location = new System.Drawing.Point(58, 206);
			this.label42.Name = "label42";
			this.label42.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label42.Size = new System.Drawing.Size(40, 23);
			this.label42.TabIndex = 121;
			this.label42.Text = "A:";
			this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// lbl_RolNombre
			// 
			this.lbl_RolNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.lbl_RolNombre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_RolNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_RolNombre.Location = new System.Drawing.Point(58, 232);
			this.lbl_RolNombre.Name = "lbl_RolNombre";
			this.lbl_RolNombre.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.lbl_RolNombre.Size = new System.Drawing.Size(445, 23);
			this.lbl_RolNombre.TabIndex = 120;
			this.lbl_RolNombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label40
			// 
			this.label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label40.Location = new System.Drawing.Point(226, 100);
			this.label40.Name = "label40";
			this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label40.Size = new System.Drawing.Size(95, 23);
			this.label40.TabIndex = 119;
			this.label40.Text = "GRUPO";
			this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label36
			// 
			this.label36.BackColor = System.Drawing.Color.DarkRed;
			this.label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label36.Location = new System.Drawing.Point(615, 20);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(4, 360);
			this.label36.TabIndex = 117;
			// 
			// label35
			// 
			this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label35.Location = new System.Drawing.Point(417, 126);
			this.label35.Name = "label35";
			this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label35.Size = new System.Drawing.Size(177, 23);
			this.label35.TabIndex = 116;
			this.label35.Text = "<-- Seleccionar";
			this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBox2
			// 
			this.comboBox2.BackColor = System.Drawing.SystemColors.Window;
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(15, 66);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(396, 21);
			this.comboBox2.TabIndex = 114;
			this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.ComboBox2SelectedIndexChanged);
			// 
			// label10
			// 
			this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
			this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(417, 63);
			this.label10.Name = "label10";
			this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label10.Size = new System.Drawing.Size(177, 23);
			this.label10.TabIndex = 115;
			this.label10.Text = "<-- Seleccionar";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBox1
			// 
			this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
									"DOCENTE",
									"ADMINISTRATIVO"});
			this.comboBox1.Location = new System.Drawing.Point(226, 126);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(185, 21);
			this.comboBox1.TabIndex = 68;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1SelectedIndexChanged);
			// 
			// Btn_cerrar
			// 
			this.Btn_cerrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_cerrar.Location = new System.Drawing.Point(805, 548);
			this.Btn_cerrar.Name = "Btn_cerrar";
			this.Btn_cerrar.Size = new System.Drawing.Size(230, 37);
			this.Btn_cerrar.TabIndex = 89;
			this.Btn_cerrar.Text = "&Salir del Registro";
			this.Btn_cerrar.UseVisualStyleBackColor = true;
			this.Btn_cerrar.Click += new System.EventHandler(this.Btn_cerrarClick);
			// 
			// FormDatos
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(1066, 607);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.Btn_cerrar);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FormDatos";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Registro del Empleado";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormDatosFormClosing);
			this.Load += new System.EventHandler(this.FormDatosLoad);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.groupBox10.ResumeLayout(false);
			this.groupBox9.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.Pic_Foto)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			this.groupBox11.ResumeLayout(false);
			this.groupBox12.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.Pic_Foto2)).EndInit();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			this.tabPage3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.tabPage4.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.Label label36;
		private System.Windows.Forms.Label label40;
		private System.Windows.Forms.Label lbl_RolNombre;
		private System.Windows.Forms.Label label42;
		private System.Windows.Forms.Label label43;
		private System.Windows.Forms.Label lbl_TipoRol;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label45;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.ComboBox Cbx_Txt_Depto;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
		private System.Windows.Forms.Button Btn_ruta2;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.GroupBox groupBox12;
		private System.Windows.Forms.GroupBox groupBox11;
		private System.Windows.Forms.GroupBox groupBox10;
		private System.Windows.Forms.Button Btn_Ficha;
		private System.Windows.Forms.Button btnSelector;
		private System.Windows.Forms.Label lblSeleccionar;
		private System.Windows.Forms.ComboBox cbx_lista;
		private System.Windows.Forms.Button btnActual;
		private System.Windows.Forms.PictureBox Pic_Foto2;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.TextBox Txt_telCasa2;
		private System.Windows.Forms.TextBox Txt_celular2;
		private System.Windows.Forms.TextBox Txt_Mail2;
		private System.Windows.Forms.TextBox Txt_Depto2;
		private System.Windows.Forms.TextBox Txt_Puesto2;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.RichTextBox Rch_Comentario2;
		private System.Windows.Forms.RichTextBox Rch_Direccion2;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.ComboBox cmbRol2;
		private System.Windows.Forms.RadioButton rb_Hombre2;
		private System.Windows.Forms.RadioButton rb_Mujer2;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.TextBox Txt_Nombre2;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.TextBox Txt_curp2;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label lbl_claveid2;
		private System.Windows.Forms.ComboBox CmbActivo;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label37;
		private System.Windows.Forms.Label label38;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox cmbRol;
		private System.Windows.Forms.ComboBox cmbStatus;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button Btn_Nuevo;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Button Btn_cerrar;
		private System.Windows.Forms.Button Btn_cancelar;
		private System.Windows.Forms.RichTextBox Rch_Direccion;
		private System.Windows.Forms.Button Btn_guardar;
		private System.Windows.Forms.Button Btn_ruta;
		private System.Windows.Forms.PictureBox Pic_Foto;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RadioButton rb_Hombre;
		private System.Windows.Forms.RadioButton rb_Mujer;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.TextBox Txt_Nombre;
		private System.Windows.Forms.Label lbl_claveid;
		private System.Windows.Forms.TextBox Txt_curp;
		private System.Windows.Forms.TextBox Txt_telCasa;
		private System.Windows.Forms.TextBox Txt_celular;
		private System.Windows.Forms.TextBox Txt_Mail;
		private System.Windows.Forms.TextBox Txt_Depto;
		private System.Windows.Forms.TextBox Txt_Puesto;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.RichTextBox Rch_Comentario;
		private System.Windows.Forms.Label label20;
		
		
	}
}
