﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 15/09/2013
 * Time: 10:02 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 
namespace PersonalNet
{
	partial class FormAccess
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// FormAccess
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Text = "FormAccess";
			this.Name = "FormAccess";
		}
	}
}
*/
namespace PersonalNet
{
    partial class FormAccess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.panel1 = new System.Windows.Forms.Panel();
        	this.okButton = new System.Windows.Forms.Button();
        	this.cancelButton = new System.Windows.Forms.Button();
        	this.panel2 = new System.Windows.Forms.Panel();
        	this.password = new System.Windows.Forms.TextBox();
        	this.label2 = new System.Windows.Forms.Label();
        	this.userID = new System.Windows.Forms.TextBox();
        	this.label1 = new System.Windows.Forms.Label();
        	this.panel1.SuspendLayout();
        	this.panel2.SuspendLayout();
        	this.SuspendLayout();
        	// 
        	// panel1
        	// 
        	this.panel1.Controls.Add(this.okButton);
        	this.panel1.Controls.Add(this.cancelButton);
        	this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
        	this.panel1.Location = new System.Drawing.Point(0, 53);
        	this.panel1.Margin = new System.Windows.Forms.Padding(2);
        	this.panel1.Name = "panel1";
        	this.panel1.Size = new System.Drawing.Size(196, 31);
        	this.panel1.TabIndex = 1;
        	// 
        	// okButton
        	// 
        	this.okButton.Location = new System.Drawing.Point(8, 4);
        	this.okButton.Margin = new System.Windows.Forms.Padding(2);
        	this.okButton.Name = "okButton";
        	this.okButton.Size = new System.Drawing.Size(50, 25);
        	this.okButton.TabIndex = 2;
        	this.okButton.Text = "OK";
        	this.okButton.UseVisualStyleBackColor = true;
        	this.okButton.Click += new System.EventHandler(this.okButton_Click);
        	// 
        	// cancelButton
        	// 
        	this.cancelButton.Location = new System.Drawing.Point(135, 6);
        	this.cancelButton.Margin = new System.Windows.Forms.Padding(2);
        	this.cancelButton.Name = "cancelButton";
        	this.cancelButton.Size = new System.Drawing.Size(50, 25);
        	this.cancelButton.TabIndex = 3;
        	this.cancelButton.Text = "Cancel";
        	this.cancelButton.UseVisualStyleBackColor = true;
        	this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
        	// 
        	// panel2
        	// 
        	this.panel2.Controls.Add(this.password);
        	this.panel2.Controls.Add(this.label2);
        	this.panel2.Controls.Add(this.userID);
        	this.panel2.Controls.Add(this.label1);
        	this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
        	this.panel2.Location = new System.Drawing.Point(0, 0);
        	this.panel2.Margin = new System.Windows.Forms.Padding(2);
        	this.panel2.Name = "panel2";
        	this.panel2.Size = new System.Drawing.Size(196, 53);
        	this.panel2.TabIndex = 0;
        	// 
        	// password
        	// 
        	this.password.Location = new System.Drawing.Point(64, 29);
        	this.password.Margin = new System.Windows.Forms.Padding(2);
        	this.password.Name = "password";
        	this.password.PasswordChar = '*';
        	this.password.Size = new System.Drawing.Size(118, 20);
        	this.password.TabIndex = 1;
        	// 
        	// label2
        	// 
        	this.label2.AutoSize = true;
        	this.label2.Location = new System.Drawing.Point(8, 32);
        	this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
        	this.label2.Name = "label2";
        	this.label2.Size = new System.Drawing.Size(53, 13);
        	this.label2.TabIndex = 2;
        	this.label2.Text = "Password";
        	// 
        	// userID
        	// 
        	this.userID.Location = new System.Drawing.Point(64, 8);
        	this.userID.Margin = new System.Windows.Forms.Padding(2);
        	this.userID.Name = "userID";
        	this.userID.Size = new System.Drawing.Size(118, 20);
        	this.userID.TabIndex = 0;
        	this.userID.Visible = false;
        	// 
        	// label1
        	// 
        	this.label1.AutoSize = true;
        	this.label1.Location = new System.Drawing.Point(8, 12);
        	this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
        	this.label1.Name = "label1";
        	this.label1.Size = new System.Drawing.Size(43, 13);
        	this.label1.TabIndex = 0;
        	this.label1.Text = "User ID";
        	this.label1.Visible = false;
        	// 
        	// FormAccess
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(196, 84);
        	this.ControlBox = false;
        	this.Controls.Add(this.panel2);
        	this.Controls.Add(this.panel1);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        	this.Margin = new System.Windows.Forms.Padding(2);
        	this.Name = "FormAccess";
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        	this.Text = "Login Acceso";
        	this.TopMost = true;
        	this.panel1.ResumeLayout(false);
        	this.panel2.ResumeLayout(false);
        	this.panel2.PerformLayout();
        	this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox userID;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Label label2;
        
        void okButton_Click(object sender, System.EventArgs e)
        {
        	
        }
        
        void cancelButton_Click(object sender, System.EventArgs e)
        {
        	
        }
    }
}