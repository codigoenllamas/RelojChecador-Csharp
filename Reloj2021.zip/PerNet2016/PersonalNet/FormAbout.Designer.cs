﻿namespace PersonalNet
{
    partial class FormAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAbout));
        	this.panel1 = new System.Windows.Forms.Panel();
        	this.okButton = new System.Windows.Forms.Button();
        	this.cancelButton = new System.Windows.Forms.Button();
        	this.panel2 = new System.Windows.Forms.Panel();
        	this.tabControl1 = new System.Windows.Forms.TabControl();
        	this.tabPage1 = new System.Windows.Forms.TabPage();
        	this.tabPage2 = new System.Windows.Forms.TabPage();
        	this.tabPage3 = new System.Windows.Forms.TabPage();
        	this.panel1.SuspendLayout();
        	this.panel2.SuspendLayout();
        	this.tabControl1.SuspendLayout();
        	this.SuspendLayout();
        	// 
        	// panel1
        	// 
        	this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        	this.panel1.Controls.Add(this.okButton);
        	this.panel1.Controls.Add(this.cancelButton);
        	this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
        	this.panel1.Location = new System.Drawing.Point(0, 358);
        	this.panel1.Margin = new System.Windows.Forms.Padding(2);
        	this.panel1.Name = "panel1";
        	this.panel1.Size = new System.Drawing.Size(604, 31);
        	this.panel1.TabIndex = 1;
        	// 
        	// okButton
        	// 
        	this.okButton.BackColor = System.Drawing.Color.Cyan;
        	this.okButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.okButton.Location = new System.Drawing.Point(392, 2);
        	this.okButton.Margin = new System.Windows.Forms.Padding(2);
        	this.okButton.Name = "okButton";
        	this.okButton.Size = new System.Drawing.Size(117, 25);
        	this.okButton.TabIndex = 2;
        	this.okButton.Text = "OK";
        	this.okButton.UseVisualStyleBackColor = false;
        	this.okButton.Click += new System.EventHandler(this.okButton_Click);
        	// 
        	// cancelButton
        	// 
        	this.cancelButton.Location = new System.Drawing.Point(2, 3);
        	this.cancelButton.Margin = new System.Windows.Forms.Padding(2);
        	this.cancelButton.Name = "cancelButton";
        	this.cancelButton.Size = new System.Drawing.Size(50, 25);
        	this.cancelButton.TabIndex = 3;
        	this.cancelButton.Text = "Cancel";
        	this.cancelButton.UseVisualStyleBackColor = true;
        	this.cancelButton.Visible = false;
        	this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
        	// 
        	// panel2
        	// 
        	this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
        	this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.panel2.Controls.Add(this.tabControl1);
        	this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
        	this.panel2.Location = new System.Drawing.Point(0, 0);
        	this.panel2.Margin = new System.Windows.Forms.Padding(2);
        	this.panel2.Name = "panel2";
        	this.panel2.Size = new System.Drawing.Size(604, 358);
        	this.panel2.TabIndex = 0;
        	// 
        	// tabControl1
        	// 
        	this.tabControl1.Controls.Add(this.tabPage1);
        	this.tabControl1.Controls.Add(this.tabPage2);
        	this.tabControl1.Controls.Add(this.tabPage3);
        	this.tabControl1.Location = new System.Drawing.Point(10, 20);
        	this.tabControl1.Name = "tabControl1";
        	this.tabControl1.SelectedIndex = 0;
        	this.tabControl1.Size = new System.Drawing.Size(567, 314);
        	this.tabControl1.TabIndex = 7;
        	this.tabControl1.Visible = false;
        	// 
        	// tabPage1
        	// 
        	this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
        	this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.tabPage1.Location = new System.Drawing.Point(4, 22);
        	this.tabPage1.Name = "tabPage1";
        	this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
        	this.tabPage1.Size = new System.Drawing.Size(559, 288);
        	this.tabPage1.TabIndex = 0;
        	this.tabPage1.Text = "tabPage1";
        	// 
        	// tabPage2
        	// 
        	this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
        	this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.tabPage2.Location = new System.Drawing.Point(4, 22);
        	this.tabPage2.Name = "tabPage2";
        	this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
        	this.tabPage2.Size = new System.Drawing.Size(559, 288);
        	this.tabPage2.TabIndex = 1;
        	this.tabPage2.Text = "tabPage2";
        	// 
        	// tabPage3
        	// 
        	this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
        	this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.tabPage3.Location = new System.Drawing.Point(4, 22);
        	this.tabPage3.Name = "tabPage3";
        	this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
        	this.tabPage3.Size = new System.Drawing.Size(559, 288);
        	this.tabPage3.TabIndex = 2;
        	this.tabPage3.Text = "tabPage3";
        	// 
        	// FormAbout
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.ClientSize = new System.Drawing.Size(604, 389);
        	this.ControlBox = false;
        	this.Controls.Add(this.panel2);
        	this.Controls.Add(this.panel1);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        	this.Margin = new System.Windows.Forms.Padding(2);
        	this.Name = "FormAbout";
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        	this.Text = "About";
        	this.TopMost = true;
        	this.panel1.ResumeLayout(false);
        	this.panel2.ResumeLayout(false);
        	this.tabControl1.ResumeLayout(false);
        	this.ResumeLayout(false);
        }
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Panel panel2;
    }
}