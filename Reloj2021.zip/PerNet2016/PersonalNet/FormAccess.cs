﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 15/09/2013
 * Time: 10:02 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace PersonalNet
{
	/// <summary>
	/// Description of FormAccess.
	/// </summary>
	public partial class FormAccess : Form
	{
		public FormAccess()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
