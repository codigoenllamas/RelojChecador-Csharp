﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 25/03/2014
 * Time: 10:30 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace PersonalNet
{
	/// <summary>
	/// Description of FormCambio.
	/// </summary>
	public partial class FormCambio : Form
	{
		public FormCambio()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void ComboBox1SelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
	}
}
