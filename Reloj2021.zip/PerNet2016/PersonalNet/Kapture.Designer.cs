﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 28/06/2013
 * Time: 11:17 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class Kapture
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label24 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.Btn_RegHuella = new System.Windows.Forms.Button();
			this.btn_guardarhuella = new System.Windows.Forms.Button();
			this.cmbEmpleado = new System.Windows.Forms.ComboBox();
			this.button2 = new System.Windows.Forms.Button();
			this.btn_limpiar = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label24
			// 
			this.label24.BackColor = System.Drawing.Color.DarkRed;
			this.label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label24.Location = new System.Drawing.Point(88, 260);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(750, 4);
			this.label24.TabIndex = 48;
			// 
			// label22
			// 
			this.label22.BackColor = System.Drawing.Color.DarkRed;
			this.label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label22.Location = new System.Drawing.Point(182, 45);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(493, 4);
			this.label22.TabIndex = 45;
			// 
			// label21
			// 
			this.label21.BackColor = System.Drawing.Color.DarkRed;
			this.label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label21.Location = new System.Drawing.Point(839, 15);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(4, 400);
			this.label21.TabIndex = 44;
			// 
			// label19
			// 
			this.label19.BackColor = System.Drawing.Color.DarkRed;
			this.label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label19.Location = new System.Drawing.Point(78, 24);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(4, 400);
			this.label19.TabIndex = 43;
			// 
			// Btn_RegHuella
			// 
			this.Btn_RegHuella.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.Btn_RegHuella.Cursor = System.Windows.Forms.Cursors.Hand;
			this.Btn_RegHuella.FlatAppearance.BorderColor = System.Drawing.Color.Blue;
			this.Btn_RegHuella.FlatAppearance.BorderSize = 40;
			this.Btn_RegHuella.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
			this.Btn_RegHuella.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
			this.Btn_RegHuella.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Btn_RegHuella.Location = new System.Drawing.Point(661, 196);
			this.Btn_RegHuella.Name = "Btn_RegHuella";
			this.Btn_RegHuella.Size = new System.Drawing.Size(110, 50);
			this.Btn_RegHuella.TabIndex = 42;
			this.Btn_RegHuella.Text = "&Capturar";
			this.Btn_RegHuella.UseVisualStyleBackColor = true;
			this.Btn_RegHuella.Click += new System.EventHandler(this.Btn_RegHuellaClick);
			// 
			// btn_guardarhuella
			// 
			this.btn_guardarhuella.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_guardarhuella.ForeColor = System.Drawing.Color.Navy;
			this.btn_guardarhuella.Location = new System.Drawing.Point(385, 286);
			this.btn_guardarhuella.Name = "btn_guardarhuella";
			this.btn_guardarhuella.Size = new System.Drawing.Size(179, 45);
			this.btn_guardarhuella.TabIndex = 49;
			this.btn_guardarhuella.Text = "Guardar Registro ";
			this.btn_guardarhuella.UseVisualStyleBackColor = true;
			this.btn_guardarhuella.Click += new System.EventHandler(this.Button1Click);
			// 
			// cmbEmpleado
			// 
			this.cmbEmpleado.FormattingEnabled = true;
			this.cmbEmpleado.Location = new System.Drawing.Point(259, 62);
			this.cmbEmpleado.Name = "cmbEmpleado";
			this.cmbEmpleado.Size = new System.Drawing.Size(362, 21);
			this.cmbEmpleado.TabIndex = 50;
			this.cmbEmpleado.SelectedIndexChanged += new System.EventHandler(this.CmbEmpleadoSelectedIndexChanged);
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.ForeColor = System.Drawing.Color.Red;
			this.button2.Location = new System.Drawing.Point(627, 286);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(144, 45);
			this.button2.TabIndex = 51;
			this.button2.Text = "Cerrar";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// btn_limpiar
			// 
			this.btn_limpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_limpiar.ForeColor = System.Drawing.Color.Purple;
			this.btn_limpiar.Location = new System.Drawing.Point(192, 286);
			this.btn_limpiar.Name = "btn_limpiar";
			this.btn_limpiar.Size = new System.Drawing.Size(105, 45);
			this.btn_limpiar.TabIndex = 53;
			this.btn_limpiar.Text = "Limpiar";
			this.btn_limpiar.UseVisualStyleBackColor = true;
			this.btn_limpiar.Click += new System.EventHandler(this.Btn_limpiarClick);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Blue;
			this.label1.Location = new System.Drawing.Point(182, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(493, 23);
			this.label1.TabIndex = 54;
			this.label1.Text = "SELECCIONAR";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Blue;
			this.label2.Location = new System.Drawing.Point(627, 58);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(141, 23);
			this.label2.TabIndex = 55;
			this.label2.Text = "<-Empleado";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// Kapture
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(884, 450);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_limpiar);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.cmbEmpleado);
			this.Controls.Add(this.btn_guardarhuella);
			this.Controls.Add(this.label24);
			this.Controls.Add(this.label22);
			this.Controls.Add(this.label21);
			this.Controls.Add(this.label19);
			this.Controls.Add(this.Btn_RegHuella);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Kapture";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Registro de Huella";
			this.Load += new System.EventHandler(this.KaptureLoad);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btn_limpiar;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ComboBox cmbEmpleado;
		private System.Windows.Forms.Button btn_guardarhuella;
		private System.Windows.Forms.Button Btn_RegHuella;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label24;
	}
}
