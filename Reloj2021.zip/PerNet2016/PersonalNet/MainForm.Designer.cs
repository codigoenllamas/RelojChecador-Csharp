﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 24/08/2013
 * Time: 07:20 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.btn_captura = new System.Windows.Forms.Button();
			this.btnVerifyFP = new System.Windows.Forms.Button();
			this.Cerrar_session = new System.Windows.Forms.Button();
			this.btn_Empleado = new System.Windows.Forms.Button();
			this.btnHorarios = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.btnConfigurar = new System.Windows.Forms.Button();
			this.btnMovimiento = new System.Windows.Forms.Button();
			this.btnUploadFG = new System.Windows.Forms.Button();
			this.btnReportex = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// btn_captura
			// 
			this.btn_captura.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_captura.ForeColor = System.Drawing.Color.Blue;
			this.btn_captura.Image = ((System.Drawing.Image)(resources.GetObject("btn_captura.Image")));
			this.btn_captura.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_captura.Location = new System.Drawing.Point(216, 138);
			this.btn_captura.Margin = new System.Windows.Forms.Padding(1);
			this.btn_captura.Name = "btn_captura";
			this.btn_captura.Size = new System.Drawing.Size(290, 60);
			this.btn_captura.TabIndex = 0;
			this.btn_captura.Text = "Registro Digital";
			this.btn_captura.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_captura.UseVisualStyleBackColor = true;
			this.btn_captura.Click += new System.EventHandler(this.Button1Click);
			// 
			// btnVerifyFP
			// 
			this.btnVerifyFP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.btnVerifyFP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.btnVerifyFP.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnVerifyFP.ForeColor = System.Drawing.Color.Purple;
			this.btnVerifyFP.Image = ((System.Drawing.Image)(resources.GetObject("btnVerifyFP.Image")));
			this.btnVerifyFP.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnVerifyFP.Location = new System.Drawing.Point(216, 10);
			this.btnVerifyFP.Margin = new System.Windows.Forms.Padding(1);
			this.btnVerifyFP.Name = "btnVerifyFP";
			this.btnVerifyFP.Size = new System.Drawing.Size(290, 60);
			this.btnVerifyFP.TabIndex = 3;
			this.btnVerifyFP.Text = "Checar Asistencia";
			this.btnVerifyFP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnVerifyFP.UseVisualStyleBackColor = true;
			this.btnVerifyFP.Click += new System.EventHandler(this.BtnVerifyFPClick);
			// 
			// Cerrar_session
			// 
			this.Cerrar_session.Location = new System.Drawing.Point(39, 385);
			this.Cerrar_session.Margin = new System.Windows.Forms.Padding(1);
			this.Cerrar_session.Name = "Cerrar_session";
			this.Cerrar_session.Size = new System.Drawing.Size(138, 49);
			this.Cerrar_session.TabIndex = 4;
			this.Cerrar_session.Text = "Cerrar";
			this.Cerrar_session.UseVisualStyleBackColor = true;
			this.Cerrar_session.Visible = false;
			this.Cerrar_session.Click += new System.EventHandler(this.Cerrar_sessionClick);
			// 
			// btn_Empleado
			// 
			this.btn_Empleado.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.btn_Empleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_Empleado.ForeColor = System.Drawing.Color.DarkGreen;
			this.btn_Empleado.Image = ((System.Drawing.Image)(resources.GetObject("btn_Empleado.Image")));
			this.btn_Empleado.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_Empleado.Location = new System.Drawing.Point(216, 74);
			this.btn_Empleado.Margin = new System.Windows.Forms.Padding(1);
			this.btn_Empleado.Name = "btn_Empleado";
			this.btn_Empleado.Size = new System.Drawing.Size(290, 60);
			this.btn_Empleado.TabIndex = 6;
			this.btn_Empleado.Text = "Registro de Personal";
			this.btn_Empleado.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Empleado.UseVisualStyleBackColor = true;
			this.btn_Empleado.Click += new System.EventHandler(this.Btn_EmpleadoClick);
			// 
			// btnHorarios
			// 
			this.btnHorarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnHorarios.ForeColor = System.Drawing.Color.Red;
			this.btnHorarios.Image = ((System.Drawing.Image)(resources.GetObject("btnHorarios.Image")));
			this.btnHorarios.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnHorarios.Location = new System.Drawing.Point(216, 392);
			this.btnHorarios.Margin = new System.Windows.Forms.Padding(1);
			this.btnHorarios.Name = "btnHorarios";
			this.btnHorarios.Size = new System.Drawing.Size(290, 60);
			this.btnHorarios.TabIndex = 7;
			this.btnHorarios.Text = "Sistema de Horarios";
			this.btnHorarios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnHorarios.UseVisualStyleBackColor = true;
			this.btnHorarios.Visible = false;
			this.btnHorarios.Click += new System.EventHandler(this.Button3Click);
			// 
			// button2
			// 
			this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
			this.button2.FlatAppearance.BorderSize = 4;
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.ForeColor = System.Drawing.Color.Blue;
			this.button2.Location = new System.Drawing.Point(523, 392);
			this.button2.Margin = new System.Windows.Forms.Padding(1);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(177, 51);
			this.button2.TabIndex = 8;
			this.button2.Text = "&Salir del Programa";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// btnConfigurar
			// 
			this.btnConfigurar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.btnConfigurar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnConfigurar.ForeColor = System.Drawing.Color.Green;
			this.btnConfigurar.Image = ((System.Drawing.Image)(resources.GetObject("btnConfigurar.Image")));
			this.btnConfigurar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnConfigurar.Location = new System.Drawing.Point(216, 330);
			this.btnConfigurar.Margin = new System.Windows.Forms.Padding(1);
			this.btnConfigurar.Name = "btnConfigurar";
			this.btnConfigurar.Size = new System.Drawing.Size(290, 60);
			this.btnConfigurar.TabIndex = 9;
			this.btnConfigurar.Text = "Complementos";
			this.btnConfigurar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnConfigurar.UseVisualStyleBackColor = true;
			this.btnConfigurar.Click += new System.EventHandler(this.BtnConfigurarClick);
			// 
			// btnMovimiento
			// 
			this.btnMovimiento.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.btnMovimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMovimiento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.btnMovimiento.Image = ((System.Drawing.Image)(resources.GetObject("btnMovimiento.Image")));
			this.btnMovimiento.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnMovimiento.Location = new System.Drawing.Point(216, 264);
			this.btnMovimiento.Margin = new System.Windows.Forms.Padding(1);
			this.btnMovimiento.Name = "btnMovimiento";
			this.btnMovimiento.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btnMovimiento.Size = new System.Drawing.Size(290, 60);
			this.btnMovimiento.TabIndex = 10;
			this.btnMovimiento.Text = "Movimiento y Asistencia";
			this.btnMovimiento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnMovimiento.UseVisualStyleBackColor = true;
			this.btnMovimiento.Click += new System.EventHandler(this.BtnMovimientoClick);
			// 
			// btnUploadFG
			// 
			this.btnUploadFG.Location = new System.Drawing.Point(613, 25);
			this.btnUploadFG.Margin = new System.Windows.Forms.Padding(2);
			this.btnUploadFG.Name = "btnUploadFG";
			this.btnUploadFG.Size = new System.Drawing.Size(76, 33);
			this.btnUploadFG.TabIndex = 12;
			this.btnUploadFG.Text = "button3";
			this.btnUploadFG.UseVisualStyleBackColor = true;
			this.btnUploadFG.Visible = false;
			this.btnUploadFG.Click += new System.EventHandler(this.BtnUploadFGClick);
			// 
			// btnReportex
			// 
			this.btnReportex.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReportex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.btnReportex.Image = ((System.Drawing.Image)(resources.GetObject("btnReportex.Image")));
			this.btnReportex.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnReportex.Location = new System.Drawing.Point(216, 200);
			this.btnReportex.Name = "btnReportex";
			this.btnReportex.Size = new System.Drawing.Size(290, 60);
			this.btnReportex.TabIndex = 13;
			this.btnReportex.Text = "Reporte (Informe)";
			this.btnReportex.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnReportex.UseVisualStyleBackColor = true;
			this.btnReportex.Click += new System.EventHandler(this.BtnReportexClick);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Cyan;
			this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
			this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Location = new System.Drawing.Point(6, 10);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(149, 69);
			this.panel1.TabIndex = 14;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel1Paint);
			// 
			// MainForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.Color.Turquoise;
			this.ClientSize = new System.Drawing.Size(704, 450);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.btnReportex);
			this.Controls.Add(this.btnUploadFG);
			this.Controls.Add(this.btnMovimiento);
			this.Controls.Add(this.btnConfigurar);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.btnHorarios);
			this.Controls.Add(this.btn_Empleado);
			this.Controls.Add(this.Cerrar_session);
			this.Controls.Add(this.btnVerifyFP);
			this.Controls.Add(this.btn_captura);
			this.DoubleBuffered = true;
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Checador Electronico con Lector Ver 2.0";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainFormFormClosed);
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnReportex;
		private System.Windows.Forms.Button btnUploadFG;
		private System.Windows.Forms.Button btnMovimiento;
		private System.Windows.Forms.Button btnConfigurar;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button btnHorarios;
		private System.Windows.Forms.Button btn_Empleado;
		private System.Windows.Forms.Button Cerrar_session;
		private System.Windows.Forms.Button btnVerifyFP;
		private System.Windows.Forms.Button btn_captura;
	}
}
