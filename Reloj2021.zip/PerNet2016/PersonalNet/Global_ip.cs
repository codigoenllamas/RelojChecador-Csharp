﻿/*
 * Creado por SharpDevelop.
 * Usuario: sysadmin
 * Fecha: 15/06/2011
 * Hora: 05:44 p.m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
using System;

namespace PersonalNet
{
	/// <summary>
	/// Description of Global_ip.
	/// </summary>
	static class Global_ip
	{
      private static string m_globalip = "";
      public static string Globalip
      	 {
        get { return m_globalip; }
         set { m_globalip = value; }
        }
		
		}
	}

 