﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 23/06/2013
 * Time: 12:59 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace PersonalNet
{
	/// <summary>
	/// Description of Horarios.
	/// </summary>
	public partial class Horarios : Form
	{
		public Horarios()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		// 
		
		void HorariosLoad(object sender, EventArgs e)
		{
	            /*	
				foreach (DataGridViewRow row in dataGridView1.Rows) 
			     if (Convert.ToInt32(row.Cells[7].Value) < Convert.ToInt32(row.Cells[10].Value)) 
			     {
			         row.DefaultCellStyle.BackColor = Color.Red; 
			     }
                */			
		}
	}
}
