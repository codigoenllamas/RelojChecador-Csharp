﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 15/12/2014
 * Time: 11:11 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class FormHora
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.HoraDown = new System.Windows.Forms.NumericUpDown();
			this.MinutoDown = new System.Windows.Forms.NumericUpDown();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.etiqueta = new System.Windows.Forms.Label();
			this.lbl_fecha = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.HoraDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.MinutoDown)).BeginInit();
			this.SuspendLayout();
			// 
			// HoraDown
			// 
			this.HoraDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HoraDown.Location = new System.Drawing.Point(45, 136);
			this.HoraDown.Maximum = new decimal(new int[] {
									23,
									0,
									0,
									0});
			this.HoraDown.Minimum = new decimal(new int[] {
									1,
									0,
									0,
									0});
			this.HoraDown.Name = "HoraDown";
			this.HoraDown.Size = new System.Drawing.Size(49, 23);
			this.HoraDown.TabIndex = 0;
			this.HoraDown.Value = new decimal(new int[] {
									1,
									0,
									0,
									0});
			// 
			// MinutoDown
			// 
			this.MinutoDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.MinutoDown.Location = new System.Drawing.Point(119, 136);
			this.MinutoDown.Maximum = new decimal(new int[] {
									59,
									0,
									0,
									0});
			this.MinutoDown.Name = "MinutoDown";
			this.MinutoDown.Size = new System.Drawing.Size(42, 23);
			this.MinutoDown.TabIndex = 1;
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(34, 165);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(152, 37);
			this.button1.TabIndex = 2;
			this.button1.Text = "Actualizar";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(45, 110);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Hora";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(119, 110);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(42, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Min.";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label3.Location = new System.Drawing.Point(2, 18);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(231, 49);
			this.label3.TabIndex = 5;
			this.label3.Text = "label3";
			// 
			// etiqueta
			// 
			this.etiqueta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.etiqueta.Location = new System.Drawing.Point(2, 76);
			this.etiqueta.Name = "etiqueta";
			this.etiqueta.Size = new System.Drawing.Size(49, 22);
			this.etiqueta.TabIndex = 6;
			this.etiqueta.Text = "Fecha:";
			// 
			// lbl_fecha
			// 
			this.lbl_fecha.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_fecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_fecha.Location = new System.Drawing.Point(57, 76);
			this.lbl_fecha.Name = "lbl_fecha";
			this.lbl_fecha.Size = new System.Drawing.Size(152, 22);
			this.lbl_fecha.TabIndex = 7;
			// 
			// FormHora
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.ClientSize = new System.Drawing.Size(234, 214);
			this.Controls.Add(this.lbl_fecha);
			this.Controls.Add(this.etiqueta);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.MinutoDown);
			this.Controls.Add(this.HoraDown);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FormHora";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Modulo Para Ajustar la Hora";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormHoraFormClosed);
			this.Load += new System.EventHandler(this.FormHoraLoad);
			((System.ComponentModel.ISupportInitialize)(this.HoraDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.MinutoDown)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label lbl_fecha;
		private System.Windows.Forms.Label etiqueta;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.NumericUpDown MinutoDown;
		private System.Windows.Forms.NumericUpDown HoraDown;
	}
}
