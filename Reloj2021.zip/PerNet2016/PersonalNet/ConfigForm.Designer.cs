﻿/*
 * Created by SharpDevelop.
 * User: pcaula
 * Date: 10/09/2013
 * Time: 12:57 a.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class ConfigForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigForm));
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.lbl_avisar = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.lbl_folio = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label37 = new System.Windows.Forms.Label();
			this.lbllbl_institucion = new System.Windows.Forms.Label();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.button5 = new System.Windows.Forms.Button();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.lbl_grupo = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.xCarrera = new System.Windows.Forms.Label();
			this.xFecha = new System.Windows.Forms.Label();
			this.xcurp = new System.Windows.Forms.Label();
			this.xid_matrix = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.xPostal = new System.Windows.Forms.Label();
			this.xTelefono = new System.Windows.Forms.Label();
			this.xCuidad = new System.Windows.Forms.Label();
			this.xCol = new System.Windows.Forms.Label();
			this.xDir = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.btn_salir = new System.Windows.Forms.Button();
			this.label16 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.lbl_nombre = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.lbl_numfolio = new System.Windows.Forms.Label();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.cmb_status = new System.Windows.Forms.ComboBox();
			this.txt_mensaje = new System.Windows.Forms.TextBox();
			this.label33 = new System.Windows.Forms.Label();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.cbx_tipo_vali = new System.Windows.Forms.ComboBox();
			this.label32 = new System.Windows.Forms.Label();
			this.txt_encargado_seg = new System.Windows.Forms.TextBox();
			this.label31 = new System.Windows.Forms.Label();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.txt_sicologo = new System.Windows.Forms.TextBox();
			this.label30 = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.label28 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.txt_NumFolio = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.Clinica = new System.Windows.Forms.GroupBox();
			this.rtb_ubicacion = new System.Windows.Forms.RichTextBox();
			this.label34 = new System.Windows.Forms.Label();
			this.rtb_plan = new System.Windows.Forms.RichTextBox();
			this.label25 = new System.Windows.Forms.Label();
			this.xNomb_Inci = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.Fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Incidencia = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Nivel = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Personal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Sancion = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Cumplimento = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Folio = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.Clinica.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabControl1.Location = new System.Drawing.Point(15, 18);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1004, 681);
			this.tabControl1.TabIndex = 2;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.lbl_avisar);
			this.tabPage1.Controls.Add(this.label17);
			this.tabPage1.Controls.Add(this.textBox1);
			this.tabPage1.Controls.Add(this.label10);
			this.tabPage1.Controls.Add(this.label6);
			this.tabPage1.Controls.Add(this.label5);
			this.tabPage1.Controls.Add(this.label4);
			this.tabPage1.Controls.Add(this.lbl_folio);
			this.tabPage1.Controls.Add(this.label9);
			this.tabPage1.Controls.Add(this.label3);
			this.tabPage1.Controls.Add(this.label2);
			this.tabPage1.Controls.Add(this.label37);
			this.tabPage1.Controls.Add(this.lbllbl_institucion);
			this.tabPage1.Controls.Add(this.pictureBox3);
			this.tabPage1.Controls.Add(this.button5);
			this.tabPage1.Controls.Add(this.pictureBox2);
			this.tabPage1.Controls.Add(this.lbl_grupo);
			this.tabPage1.Controls.Add(this.label35);
			this.tabPage1.Controls.Add(this.button4);
			this.tabPage1.Controls.Add(this.button3);
			this.tabPage1.Controls.Add(this.button1);
			this.tabPage1.Controls.Add(this.xCarrera);
			this.tabPage1.Controls.Add(this.xFecha);
			this.tabPage1.Controls.Add(this.xcurp);
			this.tabPage1.Controls.Add(this.xid_matrix);
			this.tabPage1.Controls.Add(this.groupBox3);
			this.tabPage1.Controls.Add(this.label20);
			this.tabPage1.Controls.Add(this.pictureBox1);
			this.tabPage1.Controls.Add(this.btn_salir);
			this.tabPage1.Controls.Add(this.label16);
			this.tabPage1.Controls.Add(this.label12);
			this.tabPage1.Controls.Add(this.label8);
			this.tabPage1.Controls.Add(this.lbl_nombre);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabPage1.ForeColor = System.Drawing.Color.Blue;
			this.tabPage1.Location = new System.Drawing.Point(4, 26);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(996, 651);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Ficha Escolar";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// lbl_avisar
			// 
			this.lbl_avisar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_avisar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_avisar.ForeColor = System.Drawing.Color.Blue;
			this.lbl_avisar.Location = new System.Drawing.Point(205, 527);
			this.lbl_avisar.Name = "lbl_avisar";
			this.lbl_avisar.Size = new System.Drawing.Size(386, 23);
			this.lbl_avisar.TabIndex = 132;
			// 
			// label17
			// 
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.ForeColor = System.Drawing.Color.Blue;
			this.label17.Location = new System.Drawing.Point(139, 528);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(76, 19);
			this.label17.TabIndex = 131;
			this.label17.Text = "Avisar a:";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(238, 484);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(182, 26);
			this.textBox1.TabIndex = 130;
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.Blue;
			this.label10.Location = new System.Drawing.Point(139, 490);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(93, 19);
			this.label10.TabIndex = 129;
			this.label10.Text = "VIGENCIA";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.Blue;
			this.label6.Location = new System.Drawing.Point(31, 261);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(66, 19);
			this.label6.TabIndex = 128;
			this.label6.Text = "Firma";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.Blue;
			this.label5.Location = new System.Drawing.Point(130, 221);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(215, 19);
			this.label5.TabIndex = 127;
			this.label5.Text = "LIC. JVF";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.Blue;
			this.label4.Location = new System.Drawing.Point(130, 261);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(213, 19);
			this.label4.TabIndex = 126;
			this.label4.Text = "DIRECTORA DEL PLANTEL";
			// 
			// lbl_folio
			// 
			this.lbl_folio.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_folio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_folio.ForeColor = System.Drawing.Color.Blue;
			this.lbl_folio.Location = new System.Drawing.Point(231, 188);
			this.lbl_folio.Name = "lbl_folio";
			this.lbl_folio.Size = new System.Drawing.Size(114, 22);
			this.lbl_folio.TabIndex = 125;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.Blue;
			this.label9.Location = new System.Drawing.Point(130, 188);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(95, 19);
			this.label9.TabIndex = 124;
			this.label9.Text = "NUM. FOLIO";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Blue;
			this.label3.Location = new System.Drawing.Point(130, 148);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(76, 19);
			this.label3.TabIndex = 123;
			this.label3.Text = "PLANTEL";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Blue;
			this.label2.Location = new System.Drawing.Point(132, 167);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(283, 19);
			this.label2.TabIndex = 122;
			this.label2.Text = "CONALEP JUCHITAN 243";
			// 
			// label37
			// 
			this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label37.Location = new System.Drawing.Point(130, 50);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(65, 15);
			this.label37.TabIndex = 121;
			this.label37.Text = "ALUMNO:";
			// 
			// lbllbl_institucion
			// 
			this.lbllbl_institucion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbllbl_institucion.Location = new System.Drawing.Point(80, 15);
			this.lbllbl_institucion.Name = "lbllbl_institucion";
			this.lbllbl_institucion.Size = new System.Drawing.Size(304, 23);
			this.lbllbl_institucion.TabIndex = 120;
			this.lbllbl_institucion.Text = "Colegio Nacional de Educación Profesional Técnica";
			// 
			// pictureBox3
			// 
			this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
			this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
			this.pictureBox3.Location = new System.Drawing.Point(6, 11);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(46, 27);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 119;
			this.pictureBox3.TabStop = false;
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.Coral;
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.Yellow;
			this.button5.Location = new System.Drawing.Point(477, 596);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(132, 49);
			this.button5.TabIndex = 118;
			this.button5.Text = "&Impre Credencial";
			this.button5.UseVisualStyleBackColor = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
			this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox2.Location = new System.Drawing.Point(8, 72);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(24, 73);
			this.pictureBox2.TabIndex = 112;
			this.pictureBox2.TabStop = false;
			// 
			// lbl_grupo
			// 
			this.lbl_grupo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_grupo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_grupo.ForeColor = System.Drawing.Color.Blue;
			this.lbl_grupo.Location = new System.Drawing.Point(622, 148);
			this.lbl_grupo.Name = "lbl_grupo";
			this.lbl_grupo.Size = new System.Drawing.Size(186, 20);
			this.lbl_grupo.TabIndex = 117;
			// 
			// label35
			// 
			this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label35.ForeColor = System.Drawing.Color.Blue;
			this.label35.Location = new System.Drawing.Point(565, 149);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(76, 22);
			this.label35.TabIndex = 116;
			this.label35.Text = "Grupo;";
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.Violet;
			this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.Color.MidnightBlue;
			this.button4.Location = new System.Drawing.Point(191, 596);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(137, 49);
			this.button4.TabIndex = 115;
			this.button4.Text = "&Guardar Plan";
			this.button4.UseVisualStyleBackColor = false;
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.Coral;
			this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button3.ForeColor = System.Drawing.Color.Yellow;
			this.button3.Location = new System.Drawing.Point(339, 596);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(132, 49);
			this.button3.TabIndex = 114;
			this.button3.Text = "&Impresion Incidencia";
			this.button3.UseVisualStyleBackColor = false;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.PaleGreen;
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(24, 596);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(155, 49);
			this.button1.TabIndex = 113;
			this.button1.Text = "&Buscar X Matricula";
			this.button1.UseVisualStyleBackColor = false;
			// 
			// xCarrera
			// 
			this.xCarrera.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xCarrera.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xCarrera.ForeColor = System.Drawing.Color.Blue;
			this.xCarrera.Location = new System.Drawing.Point(268, 115);
			this.xCarrera.Name = "xCarrera";
			this.xCarrera.Size = new System.Drawing.Size(287, 23);
			this.xCarrera.TabIndex = 110;
			// 
			// xFecha
			// 
			this.xFecha.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xFecha.ForeColor = System.Drawing.Color.Blue;
			this.xFecha.Location = new System.Drawing.Point(769, 63);
			this.xFecha.Name = "xFecha";
			this.xFecha.Size = new System.Drawing.Size(190, 16);
			this.xFecha.TabIndex = 109;
			// 
			// xcurp
			// 
			this.xcurp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xcurp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xcurp.ForeColor = System.Drawing.Color.Blue;
			this.xcurp.Location = new System.Drawing.Point(468, 30);
			this.xcurp.Name = "xcurp";
			this.xcurp.Size = new System.Drawing.Size(252, 23);
			this.xcurp.TabIndex = 108;
			// 
			// xid_matrix
			// 
			this.xid_matrix.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xid_matrix.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xid_matrix.ForeColor = System.Drawing.Color.Blue;
			this.xid_matrix.Location = new System.Drawing.Point(130, 116);
			this.xid_matrix.Name = "xid_matrix";
			this.xid_matrix.Size = new System.Drawing.Size(114, 22);
			this.xid_matrix.TabIndex = 106;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.xPostal);
			this.groupBox3.Controls.Add(this.xTelefono);
			this.groupBox3.Controls.Add(this.xCuidad);
			this.groupBox3.Controls.Add(this.xCol);
			this.groupBox3.Controls.Add(this.xDir);
			this.groupBox3.Controls.Add(this.label14);
			this.groupBox3.Controls.Add(this.label13);
			this.groupBox3.Controls.Add(this.label11);
			this.groupBox3.Controls.Add(this.label7);
			this.groupBox3.Controls.Add(this.label15);
			this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.groupBox3.Location = new System.Drawing.Point(152, 293);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(744, 185);
			this.groupBox3.TabIndex = 95;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Direccion / Domicilio";
			// 
			// xPostal
			// 
			this.xPostal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xPostal.ForeColor = System.Drawing.Color.Blue;
			this.xPostal.Location = new System.Drawing.Point(85, 129);
			this.xPostal.Name = "xPostal";
			this.xPostal.Size = new System.Drawing.Size(590, 23);
			this.xPostal.TabIndex = 110;
			// 
			// xTelefono
			// 
			this.xTelefono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xTelefono.ForeColor = System.Drawing.Color.Blue;
			this.xTelefono.Location = new System.Drawing.Point(84, 158);
			this.xTelefono.Name = "xTelefono";
			this.xTelefono.Size = new System.Drawing.Size(590, 23);
			this.xTelefono.TabIndex = 111;
			// 
			// xCuidad
			// 
			this.xCuidad.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xCuidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xCuidad.ForeColor = System.Drawing.Color.Blue;
			this.xCuidad.Location = new System.Drawing.Point(85, 97);
			this.xCuidad.Name = "xCuidad";
			this.xCuidad.Size = new System.Drawing.Size(590, 23);
			this.xCuidad.TabIndex = 109;
			// 
			// xCol
			// 
			this.xCol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xCol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xCol.ForeColor = System.Drawing.Color.Blue;
			this.xCol.Location = new System.Drawing.Point(85, 66);
			this.xCol.Name = "xCol";
			this.xCol.Size = new System.Drawing.Size(590, 23);
			this.xCol.TabIndex = 108;
			// 
			// xDir
			// 
			this.xDir.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.xDir.ForeColor = System.Drawing.Color.Blue;
			this.xDir.Location = new System.Drawing.Point(86, 35);
			this.xDir.Name = "xDir";
			this.xDir.Size = new System.Drawing.Size(590, 23);
			this.xDir.TabIndex = 107;
			// 
			// label14
			// 
			this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.Blue;
			this.label14.Location = new System.Drawing.Point(6, 129);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(72, 22);
			this.label14.TabIndex = 13;
			this.label14.Text = "C.Postal";
			// 
			// label13
			// 
			this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.Blue;
			this.label13.Location = new System.Drawing.Point(6, 104);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(72, 22);
			this.label13.TabIndex = 12;
			this.label13.Text = "Cuidad";
			// 
			// label11
			// 
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.Blue;
			this.label11.Location = new System.Drawing.Point(6, 65);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(72, 22);
			this.label11.TabIndex = 10;
			this.label11.Text = "Colonia";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.Blue;
			this.label7.Location = new System.Drawing.Point(9, 39);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(84, 22);
			this.label7.TabIndex = 6;
			this.label7.Text = "Direccion:";
			// 
			// label15
			// 
			this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.Blue;
			this.label15.Location = new System.Drawing.Point(6, 159);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(70, 22);
			this.label15.TabIndex = 84;
			this.label15.Text = "Telefono";
			// 
			// label20
			// 
			this.label20.BackColor = System.Drawing.SystemColors.ControlLight;
			this.label20.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.ForeColor = System.Drawing.Color.Red;
			this.label20.Location = new System.Drawing.Point(755, 11);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(195, 23);
			this.label20.TabIndex = 99;
			this.label20.Text = "Copyright : Juan Vasquez Figueroa";
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Red;
			this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pictureBox1.Location = new System.Drawing.Point(31, 75);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(54, 70);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 98;
			this.pictureBox1.TabStop = false;
			// 
			// btn_salir
			// 
			this.btn_salir.BackColor = System.Drawing.Color.Blue;
			this.btn_salir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btn_salir.ForeColor = System.Drawing.Color.Lavender;
			this.btn_salir.Location = new System.Drawing.Point(648, 596);
			this.btn_salir.Name = "btn_salir";
			this.btn_salir.Size = new System.Drawing.Size(160, 49);
			this.btn_salir.TabIndex = 89;
			this.btn_salir.Text = "&Salir";
			this.btn_salir.UseVisualStyleBackColor = false;
			// 
			// label16
			// 
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.Blue;
			this.label16.Location = new System.Drawing.Point(407, 97);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(64, 22);
			this.label16.TabIndex = 85;
			this.label16.Text = "Carrera";
			// 
			// label12
			// 
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.Blue;
			this.label12.Location = new System.Drawing.Point(468, 12);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(50, 22);
			this.label12.TabIndex = 83;
			this.label12.Text = "CURP:";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.Blue;
			this.label8.Location = new System.Drawing.Point(769, 40);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(175, 17);
			this.label8.TabIndex = 81;
			this.label8.Text = "Fecha Nac.";
			// 
			// lbl_nombre
			// 
			this.lbl_nombre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lbl_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl_nombre.ForeColor = System.Drawing.Color.Blue;
			this.lbl_nombre.Location = new System.Drawing.Point(130, 75);
			this.lbl_nombre.Name = "lbl_nombre";
			this.lbl_nombre.Size = new System.Drawing.Size(385, 19);
			this.lbl_nombre.TabIndex = 79;
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Blue;
			this.label1.Location = new System.Drawing.Point(130, 97);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(76, 19);
			this.label1.TabIndex = 75;
			this.label1.Text = "Matricula";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.lbl_numfolio);
			this.tabPage2.Controls.Add(this.groupBox8);
			this.tabPage2.Controls.Add(this.txt_mensaje);
			this.tabPage2.Controls.Add(this.label33);
			this.tabPage2.Controls.Add(this.groupBox7);
			this.tabPage2.Controls.Add(this.txt_encargado_seg);
			this.tabPage2.Controls.Add(this.label31);
			this.tabPage2.Controls.Add(this.groupBox6);
			this.tabPage2.Controls.Add(this.button2);
			this.tabPage2.Controls.Add(this.groupBox4);
			this.tabPage2.Controls.Add(this.Clinica);
			this.tabPage2.Controls.Add(this.dataGridView1);
			this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabPage2.ForeColor = System.Drawing.Color.Blue;
			this.tabPage2.Location = new System.Drawing.Point(4, 26);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(996, 651);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Seguimiento";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// lbl_numfolio
			// 
			this.lbl_numfolio.Location = new System.Drawing.Point(432, 148);
			this.lbl_numfolio.Name = "lbl_numfolio";
			this.lbl_numfolio.Size = new System.Drawing.Size(100, 14);
			this.lbl_numfolio.TabIndex = 17;
			this.lbl_numfolio.Visible = false;
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.cmb_status);
			this.groupBox8.Location = new System.Drawing.Point(420, 170);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(220, 41);
			this.groupBox8.TabIndex = 16;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Status";
			// 
			// cmb_status
			// 
			this.cmb_status.FormattingEnabled = true;
			this.cmb_status.Items.AddRange(new object[] {
									"VERDE",
									"AMARILLO",
									"ROJO"});
			this.cmb_status.Location = new System.Drawing.Point(18, 14);
			this.cmb_status.Name = "cmb_status";
			this.cmb_status.Size = new System.Drawing.Size(202, 21);
			this.cmb_status.TabIndex = 15;
			// 
			// txt_mensaje
			// 
			this.txt_mensaje.ForeColor = System.Drawing.Color.Red;
			this.txt_mensaje.Location = new System.Drawing.Point(330, 266);
			this.txt_mensaje.Name = "txt_mensaje";
			this.txt_mensaje.Size = new System.Drawing.Size(607, 20);
			this.txt_mensaje.TabIndex = 15;
			// 
			// label33
			// 
			this.label33.Location = new System.Drawing.Point(330, 242);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(194, 18);
			this.label33.TabIndex = 14;
			this.label33.Text = "Mensaje Para el Alumno  (a)";
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.cbx_tipo_vali);
			this.groupBox7.Controls.Add(this.label32);
			this.groupBox7.Location = new System.Drawing.Point(650, 219);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(298, 41);
			this.groupBox7.TabIndex = 13;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Validacion";
			// 
			// cbx_tipo_vali
			// 
			this.cbx_tipo_vali.FormattingEnabled = true;
			this.cbx_tipo_vali.Items.AddRange(new object[] {
									"VERDE",
									"AMARILLO",
									"ROJO"});
			this.cbx_tipo_vali.Location = new System.Drawing.Point(62, 14);
			this.cbx_tipo_vali.Name = "cbx_tipo_vali";
			this.cbx_tipo_vali.Size = new System.Drawing.Size(158, 21);
			this.cbx_tipo_vali.TabIndex = 15;
			// 
			// label32
			// 
			this.label32.Location = new System.Drawing.Point(6, 16);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(66, 22);
			this.label32.TabIndex = 14;
			this.label32.Text = "Grado";
			// 
			// txt_encargado_seg
			// 
			this.txt_encargado_seg.ForeColor = System.Drawing.Color.Red;
			this.txt_encargado_seg.Location = new System.Drawing.Point(3, 266);
			this.txt_encargado_seg.Name = "txt_encargado_seg";
			this.txt_encargado_seg.Size = new System.Drawing.Size(321, 20);
			this.txt_encargado_seg.TabIndex = 12;
			// 
			// label31
			// 
			this.label31.Location = new System.Drawing.Point(3, 245);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(306, 18);
			this.label31.TabIndex = 11;
			this.label31.Text = "Nombre del encargado de Seguimiento";
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.radioButton3);
			this.groupBox6.Controls.Add(this.radioButton4);
			this.groupBox6.Location = new System.Drawing.Point(650, 173);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(298, 41);
			this.groupBox6.TabIndex = 9;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Existe Vinculo Directo";
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(181, 19);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(50, 16);
			this.radioButton3.TabIndex = 1;
			this.radioButton3.TabStop = true;
			this.radioButton3.Text = "&No";
			this.radioButton3.UseVisualStyleBackColor = true;
			// 
			// radioButton4
			// 
			this.radioButton4.Location = new System.Drawing.Point(40, 19);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(46, 16);
			this.radioButton4.TabIndex = 0;
			this.radioButton4.TabStop = true;
			this.radioButton4.Text = "&Si";
			this.radioButton4.UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Salmon;
			this.button2.FlatAppearance.BorderSize = 2;
			this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Yellow;
			this.button2.ForeColor = System.Drawing.Color.Magenta;
			this.button2.Location = new System.Drawing.Point(747, 141);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(190, 26);
			this.button2.TabIndex = 3;
			this.button2.Text = "Ver Calificaciones:";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.txt_sicologo);
			this.groupBox4.Controls.Add(this.label30);
			this.groupBox4.Controls.Add(this.groupBox5);
			this.groupBox4.Controls.Add(this.label28);
			this.groupBox4.Controls.Add(this.dateTimePicker1);
			this.groupBox4.Controls.Add(this.txt_NumFolio);
			this.groupBox4.Controls.Add(this.label26);
			this.groupBox4.Controls.Add(this.label29);
			this.groupBox4.Location = new System.Drawing.Point(432, 6);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(522, 129);
			this.groupBox4.TabIndex = 2;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Kardex";
			// 
			// txt_sicologo
			// 
			this.txt_sicologo.ForeColor = System.Drawing.Color.Red;
			this.txt_sicologo.Location = new System.Drawing.Point(6, 94);
			this.txt_sicologo.Name = "txt_sicologo";
			this.txt_sicologo.Size = new System.Drawing.Size(321, 20);
			this.txt_sicologo.TabIndex = 10;
			// 
			// label30
			// 
			this.label30.Location = new System.Drawing.Point(6, 73);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(247, 18);
			this.label30.TabIndex = 9;
			this.label30.Text = "Nombre de la sicologo (a)";
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.radioButton2);
			this.groupBox5.Controls.Add(this.radioButton1);
			this.groupBox5.Location = new System.Drawing.Point(333, 56);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(183, 41);
			this.groupBox5.TabIndex = 8;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Se Aplico Test.";
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(122, 19);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(50, 16);
			this.radioButton2.TabIndex = 1;
			this.radioButton2.TabStop = true;
			this.radioButton2.Text = "&No";
			this.radioButton2.UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this.radioButton1.Location = new System.Drawing.Point(22, 19);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(46, 16);
			this.radioButton1.TabIndex = 0;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "&Si";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// label28
			// 
			this.label28.Location = new System.Drawing.Point(399, 12);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(106, 16);
			this.label28.TabIndex = 6;
			this.label28.Text = "Hora Aplicacion";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(130, 36);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(240, 20);
			this.dateTimePicker1.TabIndex = 5;
			// 
			// txt_NumFolio
			// 
			this.txt_NumFolio.ForeColor = System.Drawing.Color.Red;
			this.txt_NumFolio.Location = new System.Drawing.Point(144, 12);
			this.txt_NumFolio.Name = "txt_NumFolio";
			this.txt_NumFolio.Size = new System.Drawing.Size(100, 20);
			this.txt_NumFolio.TabIndex = 4;
			// 
			// label26
			// 
			this.label26.Location = new System.Drawing.Point(6, 40);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(129, 16);
			this.label26.TabIndex = 2;
			this.label26.Text = "Fecha de Aplicacion";
			// 
			// label29
			// 
			this.label29.Location = new System.Drawing.Point(6, 16);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(106, 16);
			this.label29.TabIndex = 0;
			this.label29.Text = "Num. Folio";
			// 
			// Clinica
			// 
			this.Clinica.Controls.Add(this.rtb_ubicacion);
			this.Clinica.Controls.Add(this.label34);
			this.Clinica.Controls.Add(this.rtb_plan);
			this.Clinica.Controls.Add(this.label25);
			this.Clinica.Controls.Add(this.xNomb_Inci);
			this.Clinica.Controls.Add(this.label24);
			this.Clinica.Location = new System.Drawing.Point(6, 6);
			this.Clinica.Name = "Clinica";
			this.Clinica.Size = new System.Drawing.Size(404, 236);
			this.Clinica.TabIndex = 1;
			this.Clinica.TabStop = false;
			this.Clinica.Text = "Clinica";
			// 
			// rtb_ubicacion
			// 
			this.rtb_ubicacion.ForeColor = System.Drawing.Color.Red;
			this.rtb_ubicacion.Location = new System.Drawing.Point(0, 184);
			this.rtb_ubicacion.Name = "rtb_ubicacion";
			this.rtb_ubicacion.Size = new System.Drawing.Size(398, 46);
			this.rtb_ubicacion.TabIndex = 5;
			this.rtb_ubicacion.Text = "";
			// 
			// label34
			// 
			this.label34.Location = new System.Drawing.Point(6, 165);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(106, 16);
			this.label34.TabIndex = 4;
			this.label34.Text = "Ubicacion de la Casa";
			// 
			// rtb_plan
			// 
			this.rtb_plan.ForeColor = System.Drawing.Color.Red;
			this.rtb_plan.Location = new System.Drawing.Point(6, 89);
			this.rtb_plan.Name = "rtb_plan";
			this.rtb_plan.Size = new System.Drawing.Size(392, 72);
			this.rtb_plan.TabIndex = 3;
			this.rtb_plan.Text = "";
			// 
			// label25
			// 
			this.label25.Location = new System.Drawing.Point(6, 73);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(106, 16);
			this.label25.TabIndex = 2;
			this.label25.Text = "Plan de Trabajo";
			// 
			// xNomb_Inci
			// 
			this.xNomb_Inci.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.xNomb_Inci.ForeColor = System.Drawing.Color.Red;
			this.xNomb_Inci.Location = new System.Drawing.Point(6, 32);
			this.xNomb_Inci.Name = "xNomb_Inci";
			this.xNomb_Inci.Size = new System.Drawing.Size(392, 36);
			this.xNomb_Inci.TabIndex = 1;
			// 
			// label24
			// 
			this.label24.Location = new System.Drawing.Point(6, 16);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(106, 16);
			this.label24.TabIndex = 0;
			this.label24.Text = "Nom: Incidencia:";
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
									this.Fecha,
									this.Incidencia,
									this.Nivel,
									this.Personal,
									this.Sancion,
									this.Cumplimento,
									this.Folio});
			this.dataGridView1.Location = new System.Drawing.Point(6, 316);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(948, 322);
			this.dataGridView1.TabIndex = 0;
			// 
			// Fecha
			// 
			this.Fecha.HeaderText = "Fecha";
			this.Fecha.Name = "Fecha";
			// 
			// Incidencia
			// 
			this.Incidencia.HeaderText = "Incidencia";
			this.Incidencia.Name = "Incidencia";
			this.Incidencia.Width = 300;
			// 
			// Nivel
			// 
			this.Nivel.HeaderText = "Nivel";
			this.Nivel.Name = "Nivel";
			// 
			// Personal
			// 
			this.Personal.HeaderText = "Personal";
			this.Personal.Name = "Personal";
			this.Personal.Width = 180;
			// 
			// Sancion
			// 
			this.Sancion.HeaderText = "Sancion";
			this.Sancion.Name = "Sancion";
			this.Sancion.Width = 300;
			// 
			// Cumplimento
			// 
			this.Cumplimento.HeaderText = "Cumplimento";
			this.Cumplimento.Name = "Cumplimento";
			this.Cumplimento.Width = 20;
			// 
			// Folio
			// 
			this.Folio.HeaderText = "Folio";
			this.Folio.Name = "Folio";
			this.Folio.Width = 40;
			// 
			// ConfigForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1101, 708);
			this.Controls.Add(this.tabControl1);
			this.Name = "ConfigForm";
			this.Text = "ConfigForm";
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox5.ResumeLayout(false);
			this.Clinica.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.DataGridViewTextBoxColumn Folio;
		private System.Windows.Forms.DataGridViewTextBoxColumn Cumplimento;
		private System.Windows.Forms.DataGridViewTextBoxColumn Sancion;
		private System.Windows.Forms.DataGridViewTextBoxColumn Personal;
		private System.Windows.Forms.DataGridViewTextBoxColumn Nivel;
		private System.Windows.Forms.DataGridViewTextBoxColumn Incidencia;
		private System.Windows.Forms.DataGridViewTextBoxColumn Fecha;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label xNomb_Inci;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.RichTextBox rtb_plan;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.RichTextBox rtb_ubicacion;
		private System.Windows.Forms.GroupBox Clinica;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.TextBox txt_NumFolio;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox txt_sicologo;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.TextBox txt_encargado_seg;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.ComboBox cbx_tipo_vali;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.TextBox txt_mensaje;
		private System.Windows.Forms.ComboBox cmb_status;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.Label lbl_numfolio;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lbl_nombre;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Button btn_salir;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label xDir;
		private System.Windows.Forms.Label xCol;
		private System.Windows.Forms.Label xCuidad;
		private System.Windows.Forms.Label xTelefono;
		private System.Windows.Forms.Label xPostal;
		private System.Windows.Forms.GroupBox groupBox3;
		public System.Windows.Forms.Label xid_matrix;
		private System.Windows.Forms.Label xcurp;
		private System.Windows.Forms.Label xFecha;
		private System.Windows.Forms.Label xCarrera;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Label label35;
		public System.Windows.Forms.Label lbl_grupo;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.Label lbllbl_institucion;
		private System.Windows.Forms.Label label37;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label9;
		public System.Windows.Forms.Label lbl_folio;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label lbl_avisar;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabControl tabControl1;
	}
}
