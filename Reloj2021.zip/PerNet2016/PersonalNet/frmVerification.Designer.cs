﻿namespace PersonalNet
{
    partial class frmVerification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        	this.components = new System.ComponentModel.Container();
        	System.Windows.Forms.Label lblPrompt;
        	System.Windows.Forms.Button CloseButton;
        	System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVerification));
        	this.VerificationControl = new DPFP.Gui.Verification.VerificationControl();
        	this.Txt_idEmpleado = new System.Windows.Forms.TextBox();
        	this.dataGridView1 = new System.Windows.Forms.DataGridView();
        	this.Column4 = new System.Windows.Forms.DataGridViewImageColumn();
        	this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        	this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        	this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
        	this.LblEvento = new System.Windows.Forms.Label();
        	this.FechaLargo = new System.Windows.Forms.Label();
        	this.LblNombre = new System.Windows.Forms.Label();
        	this.LblApellidos = new System.Windows.Forms.Label();
        	this.groupBox1 = new System.Windows.Forms.GroupBox();
        	this.LblReloj = new System.Windows.Forms.Label();
        	this.pictureBox1 = new System.Windows.Forms.PictureBox();
        	this.timer1 = new System.Windows.Forms.Timer(this.components);
        	this.label2 = new System.Windows.Forms.Label();
        	this.dougScrollingTextCtrl1 = new DougScrollingText.DougScrollingTextCtrl();
        	this.label1 = new System.Windows.Forms.Label();
        	lblPrompt = new System.Windows.Forms.Label();
        	CloseButton = new System.Windows.Forms.Button();
        	((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
        	this.groupBox1.SuspendLayout();
        	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
        	this.SuspendLayout();
        	// 
        	// lblPrompt
        	// 
        	lblPrompt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        	        	        	| System.Windows.Forms.AnchorStyles.Left) 
        	        	        	| System.Windows.Forms.AnchorStyles.Right)));
        	lblPrompt.BackColor = System.Drawing.SystemColors.Window;
        	lblPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        	lblPrompt.Location = new System.Drawing.Point(169, 9);
        	lblPrompt.Name = "lblPrompt";
        	lblPrompt.Size = new System.Drawing.Size(596, 11);
        	lblPrompt.TabIndex = 6;
        	lblPrompt.Text = "To verify your identity, touch fingerprint reader with any enrolled finger.";
        	lblPrompt.Visible = false;
        	// 
        	// CloseButton
        	// 
        	CloseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
        	CloseButton.DialogResult = System.Windows.Forms.DialogResult.OK;
        	CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	CloseButton.Location = new System.Drawing.Point(809, 472);
        	CloseButton.Name = "CloseButton";
        	CloseButton.Size = new System.Drawing.Size(100, 33);
        	CloseButton.TabIndex = 5;
        	CloseButton.Text = "&Cerrar";
        	CloseButton.UseVisualStyleBackColor = true;
        	CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
        	// 
        	// VerificationControl
        	// 
        	this.VerificationControl.Active = true;
        	this.VerificationControl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
        	this.VerificationControl.Location = new System.Drawing.Point(223, 23);
        	this.VerificationControl.Name = "VerificationControl";
        	this.VerificationControl.ReaderSerialNumber = "00000000-0000-0000-0000-000000000000";
        	this.VerificationControl.Size = new System.Drawing.Size(48, 47);
        	this.VerificationControl.TabIndex = 7;
        	this.VerificationControl.OnComplete += new DPFP.Gui.Verification.VerificationControl._OnComplete(this.OnComplete);
        	// 
        	// Txt_idEmpleado
        	// 
        	this.Txt_idEmpleado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
        	this.Txt_idEmpleado.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.Txt_idEmpleado.Location = new System.Drawing.Point(186, 171);
        	this.Txt_idEmpleado.Name = "Txt_idEmpleado";
        	this.Txt_idEmpleado.Size = new System.Drawing.Size(100, 83);
        	this.Txt_idEmpleado.TabIndex = 8;
        	this.Txt_idEmpleado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        	this.Txt_idEmpleado.TextChanged += new System.EventHandler(this.TextBox1TextChanged);
        	// 
        	// dataGridView1
        	// 
        	this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
        	this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
        	this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        	this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
        	        	        	this.Column4,
        	        	        	this.Column2,
        	        	        	this.Column1,
        	        	        	this.Column3});
        	this.dataGridView1.GridColor = System.Drawing.SystemColors.Control;
        	this.dataGridView1.Location = new System.Drawing.Point(387, 194);
        	this.dataGridView1.Name = "dataGridView1";
        	this.dataGridView1.Size = new System.Drawing.Size(523, 271);
        	this.dataGridView1.TabIndex = 33;
        	// 
        	// Column4
        	// 
        	this.Column4.HeaderText = "Ok";
        	this.Column4.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Stretch;
        	this.Column4.Name = "Column4";
        	this.Column4.Width = 40;
        	// 
        	// Column2
        	// 
        	this.Column2.HeaderText = "Evento";
        	this.Column2.Name = "Column2";
        	this.Column2.Width = 70;
        	// 
        	// Column1
        	// 
        	this.Column1.HeaderText = "Empleado";
        	this.Column1.Name = "Column1";
        	this.Column1.Width = 300;
        	// 
        	// Column3
        	// 
        	this.Column3.HeaderText = "Hora";
        	this.Column3.Name = "Column3";
        	this.Column3.Width = 70;
        	// 
        	// LblEvento
        	// 
        	this.LblEvento.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.LblEvento.Font = new System.Drawing.Font("Microsoft Sans Serif", 38F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.LblEvento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
        	this.LblEvento.Location = new System.Drawing.Point(91, 371);
        	this.LblEvento.Name = "LblEvento";
        	this.LblEvento.Size = new System.Drawing.Size(279, 61);
        	this.LblEvento.TabIndex = 26;
        	this.LblEvento.Text = "Evento";
        	this.LblEvento.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        	// 
        	// FechaLargo
        	// 
        	this.FechaLargo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
        	this.FechaLargo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.FechaLargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.FechaLargo.Location = new System.Drawing.Point(554, 152);
        	this.FechaLargo.Name = "FechaLargo";
        	this.FechaLargo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
        	this.FechaLargo.Size = new System.Drawing.Size(274, 36);
        	this.FechaLargo.TabIndex = 30;
        	this.FechaLargo.Text = "Miercoles, 31 de Agosto  2015 ";
        	this.FechaLargo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        	// 
        	// LblNombre
        	// 
        	this.LblNombre.BackColor = System.Drawing.Color.Lime;
        	this.LblNombre.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.LblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.LblNombre.Location = new System.Drawing.Point(69, 286);
        	this.LblNombre.Name = "LblNombre";
        	this.LblNombre.Size = new System.Drawing.Size(312, 36);
        	this.LblNombre.TabIndex = 31;
        	this.LblNombre.Text = "Personal";
        	this.LblNombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        	// 
        	// LblApellidos
        	// 
        	this.LblApellidos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
        	this.LblApellidos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.LblApellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.LblApellidos.Location = new System.Drawing.Point(158, 116);
        	this.LblApellidos.Name = "LblApellidos";
        	this.LblApellidos.Size = new System.Drawing.Size(155, 42);
        	this.LblApellidos.TabIndex = 32;
        	this.LblApellidos.Text = "Clave de personal";
        	this.LblApellidos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        	// 
        	// groupBox1
        	// 
        	this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
        	this.groupBox1.Controls.Add(this.LblReloj);
        	this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
        	this.groupBox1.Location = new System.Drawing.Point(554, 37);
        	this.groupBox1.Name = "groupBox1";
        	this.groupBox1.Size = new System.Drawing.Size(274, 97);
        	this.groupBox1.TabIndex = 29;
        	this.groupBox1.TabStop = false;
        	// 
        	// LblReloj
        	// 
        	this.LblReloj.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.LblReloj.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.LblReloj.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
        	this.LblReloj.Location = new System.Drawing.Point(13, 14);
        	this.LblReloj.Name = "LblReloj";
        	this.LblReloj.Size = new System.Drawing.Size(250, 74);
        	this.LblReloj.TabIndex = 1;
        	this.LblReloj.Text = "00:00:00";
        	this.LblReloj.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        	// 
        	// pictureBox1
        	// 
        	this.pictureBox1.BackColor = System.Drawing.SystemColors.Window;
        	this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
        	this.pictureBox1.Location = new System.Drawing.Point(387, 37);
        	this.pictureBox1.Name = "pictureBox1";
        	this.pictureBox1.Size = new System.Drawing.Size(135, 151);
        	this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
        	this.pictureBox1.TabIndex = 28;
        	this.pictureBox1.TabStop = false;
        	this.pictureBox1.Click += new System.EventHandler(this.PictureBox1Click);
        	// 
        	// timer1
        	// 
        	this.timer1.Enabled = true;
        	this.timer1.Tick += new System.EventHandler(this.Timer1Tick);
        	// 
        	// label2
        	// 
        	this.label2.BackColor = System.Drawing.Color.Red;
        	this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.label2.Location = new System.Drawing.Point(83, 504);
        	this.label2.Name = "label2";
        	this.label2.Size = new System.Drawing.Size(714, 3);
        	this.label2.TabIndex = 36;
        	// 
        	// dougScrollingTextCtrl1
        	// 
        	this.dougScrollingTextCtrl1.BackColor = System.Drawing.Color.White;
        	this.dougScrollingTextCtrl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        	this.dougScrollingTextCtrl1.DougScrollingTextColor1 = System.Drawing.Color.Blue;
        	this.dougScrollingTextCtrl1.DougScrollingTextColor2 = System.Drawing.Color.Black;
        	this.dougScrollingTextCtrl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        	this.dougScrollingTextCtrl1.ForeColor = System.Drawing.Color.Red;
        	this.dougScrollingTextCtrl1.Location = new System.Drawing.Point(85, 479);
        	this.dougScrollingTextCtrl1.Name = "dougScrollingTextCtrl1";
        	this.dougScrollingTextCtrl1.Size = new System.Drawing.Size(712, 24);
        	this.dougScrollingTextCtrl1.TabIndex = 34;
        	this.dougScrollingTextCtrl1.Text = "En este mes";
        	// 
        	// label1
        	// 
        	this.label1.BackColor = System.Drawing.Color.Red;
        	this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        	this.label1.Location = new System.Drawing.Point(84, 476);
        	this.label1.Name = "label1";
        	this.label1.Size = new System.Drawing.Size(714, 3);
        	this.label1.TabIndex = 37;
        	// 
        	// frmVerification
        	// 
        	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        	this.BackColor = System.Drawing.Color.PaleTurquoise;
        	this.ClientSize = new System.Drawing.Size(921, 517);
        	this.Controls.Add(this.label1);
        	this.Controls.Add(this.label2);
        	this.Controls.Add(this.dougScrollingTextCtrl1);
        	this.Controls.Add(this.LblApellidos);
        	this.Controls.Add(this.dataGridView1);
        	this.Controls.Add(this.LblEvento);
        	this.Controls.Add(this.FechaLargo);
        	this.Controls.Add(this.LblNombre);
        	this.Controls.Add(this.groupBox1);
        	this.Controls.Add(this.pictureBox1);
        	this.Controls.Add(this.Txt_idEmpleado);
        	this.Controls.Add(this.VerificationControl);
        	this.Controls.Add(lblPrompt);
        	this.Controls.Add(CloseButton);
        	this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        	this.MaximizeBox = false;
        	this.MinimizeBox = false;
        	this.Name = "frmVerification";
        	this.ShowInTaskbar = false;
        	this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        	this.Text = "Pulse su número de empleado,  antes de colocar su  Huella.";
        	this.Load += new System.EventHandler(this.frmVerification_Load);
        	((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
        	this.groupBox1.ResumeLayout(false);
        	((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
        	this.ResumeLayout(false);
        	this.PerformLayout();
        }
        private DougScrollingText.DougScrollingTextCtrl dougScrollingTextCtrl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LblReloj;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LblApellidos;
        public System.Windows.Forms.Label LblNombre;
        private System.Windows.Forms.Label FechaLargo;
        public System.Windows.Forms.Label LblEvento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewImageColumn Column4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox Txt_idEmpleado;

        #endregion

       
    }
}