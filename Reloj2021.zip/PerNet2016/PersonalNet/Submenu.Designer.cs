﻿/*
 * Created by SharpDevelop.
 * User: AccesoReloj
 * Date: 05/01/2016
 * Time: 03:19 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class Submenu
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Submenu));
			this.btnMovHr = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnMovHr
			// 
			this.btnMovHr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.btnMovHr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnMovHr.ForeColor = System.Drawing.Color.Red;
			this.btnMovHr.Image = ((System.Drawing.Image)(resources.GetObject("btnMovHr.Image")));
			this.btnMovHr.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btnMovHr.Location = new System.Drawing.Point(45, 55);
			this.btnMovHr.Margin = new System.Windows.Forms.Padding(1);
			this.btnMovHr.Name = "btnMovHr";
			this.btnMovHr.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btnMovHr.Size = new System.Drawing.Size(290, 60);
			this.btnMovHr.TabIndex = 11;
			this.btnMovHr.Text = "Sistema de Horas";
			this.btnMovHr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnMovHr.UseVisualStyleBackColor = true;
			this.btnMovHr.Click += new System.EventHandler(this.BtnMovHrClick);
			// 
			// button1
			// 
			this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.Blue;
			this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
			this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.button1.Location = new System.Drawing.Point(45, 233);
			this.button1.Margin = new System.Windows.Forms.Padding(1);
			this.button1.Name = "button1";
			this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.button1.Size = new System.Drawing.Size(290, 60);
			this.button1.TabIndex = 12;
			this.button1.Text = "Sistema de Fecha";
			this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.UseVisualStyleBackColor = true;
			// 
			// Submenu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.ClientSize = new System.Drawing.Size(389, 435);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.btnMovHr);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Submenu";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Submenu";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button btnMovHr;
	}
}
