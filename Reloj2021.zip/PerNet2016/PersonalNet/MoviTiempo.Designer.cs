﻿/*
 * Created by SharpDevelop.
 * User: tablet
 * Date: 05/01/2016
 * Time: 09:00 p.m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace PersonalNet
{
	partial class MoviTiempo
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			this.cmbCambio = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.lblctrl = new System.Windows.Forms.Label();
			this.lblLaHora = new System.Windows.Forms.Label();
			this.LStatus = new System.Windows.Forms.Label();
			this.lblFecha = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.DTPFecha = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.CmbEmpleado = new System.Windows.Forms.ComboBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.btnSalir = new System.Windows.Forms.Button();
			this.btnBuscar = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.DgvMovimiento = new System.Windows.Forms.DataGridView();
			this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DgvMovimiento)).BeginInit();
			this.SuspendLayout();
			// 
			// cmbCambio
			// 
			this.cmbCambio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
			this.cmbCambio.FormattingEnabled = true;
			this.cmbCambio.Items.AddRange(new object[] {
									"ENTRADA",
									"SALIDA"});
			this.cmbCambio.Location = new System.Drawing.Point(506, 60);
			this.cmbCambio.Name = "cmbCambio";
			this.cmbCambio.Size = new System.Drawing.Size(121, 21);
			this.cmbCambio.TabIndex = 33;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label4.Location = new System.Drawing.Point(16, 30);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(80, 24);
			this.label4.TabIndex = 31;
			this.label4.Text = "Fecha";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel1.Controls.Add(this.label9);
			this.panel1.Controls.Add(this.lblctrl);
			this.panel1.Controls.Add(this.lblLaHora);
			this.panel1.Controls.Add(this.LStatus);
			this.panel1.Controls.Add(this.lblFecha);
			this.panel1.Controls.Add(this.cmbCambio);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.DTPFecha);
			this.panel1.Location = new System.Drawing.Point(27, 393);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(729, 167);
			this.panel1.TabIndex = 41;
			// 
			// lblctrl
			// 
			this.lblctrl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblctrl.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblctrl.Location = new System.Drawing.Point(173, 13);
			this.lblctrl.Name = "lblctrl";
			this.lblctrl.Size = new System.Drawing.Size(262, 11);
			this.lblctrl.TabIndex = 43;
			this.lblctrl.Text = "IDCTRL";
			this.lblctrl.Visible = false;
			// 
			// lblLaHora
			// 
			this.lblLaHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLaHora.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblLaHora.Location = new System.Drawing.Point(348, 59);
			this.lblLaHora.Name = "lblLaHora";
			this.lblLaHora.Size = new System.Drawing.Size(97, 21);
			this.lblLaHora.TabIndex = 42;
			this.lblLaHora.Text = "00:00";
			this.lblLaHora.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// LStatus
			// 
			this.LStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LStatus.ForeColor = System.Drawing.Color.Fuchsia;
			this.LStatus.Location = new System.Drawing.Point(503, 87);
			this.LStatus.Name = "LStatus";
			this.LStatus.Size = new System.Drawing.Size(124, 15);
			this.LStatus.TabIndex = 41;
			this.LStatus.Text = "STATUS";
			this.LStatus.Visible = false;
			// 
			// lblFecha
			// 
			this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFecha.ForeColor = System.Drawing.Color.Fuchsia;
			this.lblFecha.Location = new System.Drawing.Point(108, 87);
			this.lblFecha.Name = "lblFecha";
			this.lblFecha.Size = new System.Drawing.Size(124, 15);
			this.lblFecha.TabIndex = 40;
			this.lblFecha.Text = "LA FECHA";
			this.lblFecha.Visible = false;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label5.Location = new System.Drawing.Point(517, 33);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(150, 24);
			this.label5.TabIndex = 32;
			this.label5.Text = "Tipo de Movimiento";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.Blue;
			this.button1.Location = new System.Drawing.Point(263, 123);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(218, 37);
			this.button1.TabIndex = 29;
			this.button1.Text = "&Aplicar/Movimiento";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// DTPFecha
			// 
			this.DTPFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.DTPFecha.Location = new System.Drawing.Point(16, 57);
			this.DTPFecha.Name = "DTPFecha";
			this.DTPFecha.Size = new System.Drawing.Size(292, 24);
			this.DTPFecha.TabIndex = 30;
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Location = new System.Drawing.Point(292, 57);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
			this.dateTimePicker2.TabIndex = 34;
			// 
			// CmbEmpleado
			// 
			this.CmbEmpleado.FormattingEnabled = true;
			this.CmbEmpleado.Location = new System.Drawing.Point(202, 14);
			this.CmbEmpleado.Name = "CmbEmpleado";
			this.CmbEmpleado.Size = new System.Drawing.Size(360, 21);
			this.CmbEmpleado.TabIndex = 32;
			this.CmbEmpleado.SelectedIndexChanged += new System.EventHandler(this.CmbEmpleadoSelectedIndexChanged);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(27, 57);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
			this.dateTimePicker1.TabIndex = 33;
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Fuchsia;
			this.label3.Location = new System.Drawing.Point(292, 38);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(77, 16);
			this.label3.TabIndex = 40;
			this.label3.Text = "HASTA:";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Fuchsia;
			this.label2.Location = new System.Drawing.Point(27, 38);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(61, 16);
			this.label2.TabIndex = 39;
			this.label2.Text = "DESDE:";
			// 
			// btnSalir
			// 
			this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnSalir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btnSalir.Location = new System.Drawing.Point(759, 518);
			this.btnSalir.Name = "btnSalir";
			this.btnSalir.Size = new System.Drawing.Size(99, 42);
			this.btnSalir.TabIndex = 38;
			this.btnSalir.Text = "&Salir";
			this.btnSalir.UseVisualStyleBackColor = true;
			this.btnSalir.Click += new System.EventHandler(this.BtnSalirClick);
			// 
			// btnBuscar
			// 
			this.btnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnBuscar.ForeColor = System.Drawing.Color.Red;
			this.btnBuscar.Location = new System.Drawing.Point(762, 83);
			this.btnBuscar.Name = "btnBuscar";
			this.btnBuscar.Size = new System.Drawing.Size(99, 42);
			this.btnBuscar.TabIndex = 37;
			this.btnBuscar.Text = "&Buscar";
			this.btnBuscar.UseVisualStyleBackColor = true;
			this.btnBuscar.Click += new System.EventHandler(this.BtnBuscarClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label1.Location = new System.Drawing.Point(-1, 14);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(181, 24);
			this.label1.TabIndex = 36;
			this.label1.Text = "Seleccionar Empleado";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DgvMovimiento
			// 
			this.DgvMovimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DgvMovimiento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
									this.Column6,
									this.Column1,
									this.Column2,
									this.Column3,
									this.Column4,
									this.Column5});
			this.DgvMovimiento.Location = new System.Drawing.Point(27, 83);
			this.DgvMovimiento.Name = "DgvMovimiento";
			this.DgvMovimiento.Size = new System.Drawing.Size(729, 280);
			this.DgvMovimiento.TabIndex = 35;
			this.DgvMovimiento.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvMovimientoCellClick);
			this.DgvMovimiento.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvMovimientoCellContentClick);
			// 
			// Column6
			// 
			this.Column6.HeaderText = "IdCtrl";
			this.Column6.Name = "Column6";
			this.Column6.Width = 50;
			// 
			// Column1
			// 
			this.Column1.HeaderText = "Fecha";
			this.Column1.Name = "Column1";
			this.Column1.Width = 70;
			// 
			// Column2
			// 
			this.Column2.HeaderText = "Día";
			this.Column2.Name = "Column2";
			this.Column2.Width = 40;
			// 
			// Column3
			// 
			this.Column3.HeaderText = "Nombre del Empleado";
			this.Column3.Name = "Column3";
			this.Column3.Width = 200;
			// 
			// Column4
			// 
			this.Column4.HeaderText = "Movimiento";
			this.Column4.Name = "Column4";
			this.Column4.Width = 80;
			// 
			// Column5
			// 
			dataGridViewCellStyle1.Format = "T";
			dataGridViewCellStyle1.NullValue = null;
			this.Column5.DefaultCellStyle = dataGridViewCellStyle1;
			this.Column5.HeaderText = "Horas";
			this.Column5.Name = "Column5";
			this.Column5.Width = 80;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Maroon;
			this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label6.ForeColor = System.Drawing.Color.Maroon;
			this.label6.Location = new System.Drawing.Point(27, 373);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(104, 10);
			this.label6.TabIndex = 42;
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Maroon;
			this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label7.ForeColor = System.Drawing.Color.Maroon;
			this.label7.Location = new System.Drawing.Point(635, 373);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(121, 10);
			this.label7.TabIndex = 43;
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label8.Location = new System.Drawing.Point(137, 366);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(492, 24);
			this.label8.TabIndex = 44;
			this.label8.Text = "Pulse un Click; Celda Fecha : Abajo Realiza el Cambio";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
			this.label9.Location = new System.Drawing.Point(322, 31);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(150, 24);
			this.label9.TabIndex = 44;
			this.label9.Text = "Hora de Registro";
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(870, 579);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.dateTimePicker2);
			this.Controls.Add(this.CmbEmpleado);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnSalir);
			this.Controls.Add(this.btnBuscar);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.DgvMovimiento);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Proceso de Movimiento.";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DgvMovimiento)).EndInit();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label lblctrl;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label lblLaHora;
		private System.Windows.Forms.Label lblFecha;
		private System.Windows.Forms.Label LStatus;
		private System.Windows.Forms.DataGridView DgvMovimiento;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnBuscar;
		private System.Windows.Forms.Button btnSalir;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.ComboBox CmbEmpleado;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.DateTimePicker DTPFecha;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbCambio;
	}
}
